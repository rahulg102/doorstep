const fs = require('fs');
const path = require('path');

function cleanHtml(rawHtml, depth = 0) {
  const prefix = depth === 1 ? '../' : depth === 2 ? '../../' : '';

  let html = rawHtml;

  // Strip third party tracking/framework hydration scripts
  html = html.replace(/<script defer src="\/~flock\.js"[^>]*><\/script>/g, '');
  html = html.replace(/<script defer src="\/__l5e\/events\.[^>]*><\/script>/g, '');
  html = html.replace(/<script data-tsr-stream-part="">[\s\S]*?<\/script>/g, '');
  html = html.replace(/<script type="module" async="" src="\/assets\/index-[^>]*><\/script>/g, '');
  html = html.replace(/<script>document\.currentScript\.remove\(\);[\s\S]*?<\/script>/g, '');
  html = html.replace(/<script>\(function\(a,f\)[\s\S]*?<\/script>/g, '');

  // Fix assets to local
  html = html.replace(/href="\/assets\/styles-B6ITA7xY\.css"/g, `href="${prefix}assets/styles.css"`);
  html = html.replace(/href="\/brand\/favicon-option-b\.svg"/g, `href="${prefix}brand/favicon-option-b.svg"`);
  html = html.replace(/src="\/brand\/logo-selected-dark\.svg"/g, `src="${prefix}brand/logo-selected-dark.svg"`);
  html = html.replace(/src="\/brand\/bbb-logo-official\.svg"/g, `src="${prefix}brand/bbb-logo-official.svg"`);
  html = html.replace(/src="\/visuals\/brake-assembly\.svg"/g, `src="${prefix}visuals/brake-assembly.svg"`);
  html = html.replace(/href="\/brand\/logo-selected-dark\.svg"/g, `href="${prefix}brand/logo-selected-dark.svg"`);
  html = html.replace(/href="\/brand\/bbb-logo-official\.svg"/g, `href="${prefix}brand/bbb-logo-official.svg"`);
  html = html.replace(/href="\/visuals\/brake-assembly\.svg"/g, `href="${prefix}visuals/brake-assembly.svg"`);

  // Fix internal links
  html = html.replace(/href="\/used-car-parts"/g, `href="${prefix}used-car-parts.html"`);
  html = html.replace(/href="\/find-a-part\/"/g, `href="${prefix}find-a-part.html"`);
  html = html.replace(/href="\/find-a-part"/g, `href="${prefix}find-a-part.html"`);
  html = html.replace(/href="\/faq"/g, `href="${prefix}faq.html"`);
  html = html.replace(/href="\/blog"/g, `href="${prefix}blog.html"`);
  html = html.replace(/href="\/#popular-parts"/g, `href="${prefix}index.html#popular-parts"`);
  html = html.replace(/href="\/#how-it-works"/g, `href="${prefix}index.html#how-it-works"`);
  html = html.replace(/href="\/#why-doorstep"/g, `href="${prefix}index.html#why-doorstep"`);
  html = html.replace(/href="\/"/g, `href="${prefix}index.html"`);

  // Fix blog post links
  html = html.replace(/href="\/blog\/how-to-buy-a-used-engine"/g, `href="${prefix}blog/how-to-buy-a-used-engine.html"`);
  html = html.replace(/href="\/blog\/find-car-parts-by-vin"/g, `href="${prefix}blog/find-car-parts-by-vin.html"`);
  html = html.replace(/href="\/blog\/used-vs-rebuilt-vs-remanufactured-transmissions"/g, `href="${prefix}blog/used-vs-rebuilt-vs-remanufactured-transmissions.html"`);
  html = html.replace(/href="\/blog\/used-car-parts-fitment-mistakes"/g, `href="${prefix}blog/used-car-parts-fitment-mistakes.html"`);
  html = html.replace(/href="\/blog\/used-auto-parts-total-cost-guide"/g, `href="${prefix}blog/used-auto-parts-total-cost-guide.html"`);

  // Inject custom stylesheet and main.js
  const extraHead = `
    <link rel="stylesheet" href="${prefix}assets/custom.css"/>
    <script defer src="${prefix}assets/main.js"></script>
  `;
  html = html.replace('</head>', `${extraHead}</head>`);

  // Ensure "All parts" link is in the primary navigation
  if (!html.includes('all-parts.html')) {
    html = html.replace(
      `<a href="${prefix}used-car-parts.html">Used car parts</a>`,
      `<a href="${prefix}used-car-parts.html">Used car parts</a><a href="${prefix}all-parts.html">All parts</a>`
    );
    html = html.replace(
      `<a href="${prefix}used-car-parts.html">Used car parts<svg viewBox="0 0 24 24" aria-hidden="true" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><path d="M4 12h15m-6-6 6 6-6 6"></path></svg></a>`,
      `<a href="${prefix}used-car-parts.html">Used car parts<svg viewBox="0 0 24 24" aria-hidden="true" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><path d="M4 12h15m-6-6 6 6-6 6"></path></svg></a><a href="${prefix}all-parts.html">All parts directory<svg viewBox="0 0 24 24" aria-hidden="true" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><path d="M4 12h15m-6-6 6 6-6 6"></path></svg></a>`
    );
  }

  return html;
}

const PAGES_TO_FETCH = [
  { url: 'https://doorstepautoparts.com/used-car-parts', target: 'd:/antigravity/v/used-car-parts.html', depth: 0 },
  { url: 'https://doorstepautoparts.com/blog', target: 'd:/antigravity/v/blog.html', depth: 0 },
  { url: 'https://doorstepautoparts.com/blog/how-to-buy-a-used-engine', target: 'd:/antigravity/v/blog/how-to-buy-a-used-engine.html', depth: 1 },
  { url: 'https://doorstepautoparts.com/blog/find-car-parts-by-vin', target: 'd:/antigravity/v/blog/find-car-parts-by-vin.html', depth: 1 },
  { url: 'https://doorstepautoparts.com/blog/used-vs-rebuilt-vs-remanufactured-transmissions', target: 'd:/antigravity/v/blog/used-vs-rebuilt-vs-remanufactured-transmissions.html', depth: 1 },
  { url: 'https://doorstepautoparts.com/blog/used-car-parts-fitment-mistakes', target: 'd:/antigravity/v/blog/used-car-parts-fitment-mistakes.html', depth: 1 },
  { url: 'https://doorstepautoparts.com/blog/used-auto-parts-total-cost-guide', target: 'd:/antigravity/v/blog/used-auto-parts-total-cost-guide.html', depth: 1 }
];

async function run() {
  for (const page of PAGES_TO_FETCH) {
    try {
      console.log(`Fetching ${page.url}...`);
      const res = await fetch(page.url, {
        headers: { 'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36' }
      });
      if (!res.ok) {
        console.error(`Failed to fetch ${page.url}: ${res.status}`);
        continue;
      }
      const rawHtml = await res.text();
      const cleaned = cleanHtml(rawHtml, page.depth);
      fs.mkdirSync(path.dirname(page.target), { recursive: true });
      fs.writeFileSync(page.target, cleaned, 'utf-8');
      console.log(`-> Saved ${page.target} (${cleaned.length} bytes)`);
    } catch (err) {
      console.error(`Error processing ${page.url}:`, err);
    }
  }
  console.log('All target pages downloaded and cleaned successfully!');
}

run();
