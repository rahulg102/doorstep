/**
 * Doorstep Auto Parts - Core Interactive Logic
 */

const VEHICLE_MAKES = [
  "Acura", "Alfa Romeo", "AM General", "AMC", "Aston Martin", "Audi", "Austin", "Austin-Healey", "Avanti", 
  "Bentley", "BMW", "Bricklin", "Buick", "Bugatti", "Cadillac", "Checker", "Chevrolet", "Chrysler", 
  "Citroen", "Daewoo", "Daihatsu", "Datsun", "DeLorean", "DeSoto", "Dodge", "Eagle", "Edsel", "Ferrari", 
  "Fiat", "Fisker", "Ford", "Freightliner", "Genesis", "Geo", "GMC", "Honda", "Hudson", "Hummer", 
  "Hyundai", "INEOS", "Infiniti", "International", "Isuzu", "Jaguar", "Jeep", "Kaiser", "Karma", "Kia", 
  "Lamborghini", "Lancia", "Land Rover", "Lexus", "Lincoln", "Lotus", "Lucid", "Maserati", "Maybach", 
  "Mazda", "McLaren", "Mercedes-Benz", "Mercury", "Merkur", "MG", "Mini Cooper", "Mitsubishi", "Morris", 
  "Nash", "Nissan", "Oldsmobile", "Opel", "Packard", "Panoz", "Peugeot", "Plymouth", "Polestar", 
  "Pontiac", "Porsche", "Ram", "Range Rover", "Renault", "Rivian", "Rolls-Royce", "Rover", "Saab", 
  "Saleen", "Saturn", "Scion", "Smart", "Sterling", "Studebaker", "Subaru", "Sunbeam", "Suzuki", 
  "Tesla", "Toyota", "Triumph", "VinFast", "Volkswagen", "Volvo", "VPG", "Willys", "Workhorse", "Yugo"
];

const AUTO_PARTS_CATALOG = [
  // 01 Engine & Engine Components (16)
  { id: "engine-complete", name: "Complete Engine", system: "Engine & Drivetrain", sysCode: "01", slug: "engine", difficulty: "Advanced", warranty: "90-Day Standard to 1-Year", desc: "Complete long-block or full engine assembly including block, heads, internal rotating components, and available accessories." },
  { id: "engine-assembly", name: "Engine Assembly", system: "Engine & Drivetrain", sysCode: "01", slug: "engine", difficulty: "Advanced", warranty: "90-Day Standard", desc: "Core engine block and cylinder heads paired with timing components." },
  { id: "engine-block", name: "Engine Block", system: "Engine & Drivetrain", sysCode: "01", slug: "engine", difficulty: "Advanced", warranty: "90-Day Standard", desc: "Bare or short block assembly inspected for deck flatness and cylinder bore condition." },
  { id: "cylinder-head", name: "Cylinder Head", system: "Engine & Drivetrain", sysCode: "01", slug: "engine", difficulty: "Moderate", warranty: "90-Day Standard", desc: "Inspected valve guides, combustion chambers, and cam journals." },
  { id: "crankshaft", name: "Crankshaft", system: "Engine & Drivetrain", sysCode: "01", slug: "engine", difficulty: "Advanced", warranty: "90-Day Standard", desc: "Precision balanced crankshaft with micrometer-verified journal dimensions." },
  { id: "camshaft", name: "Camshaft", system: "Engine & Drivetrain", sysCode: "01", slug: "engine", difficulty: "Moderate", warranty: "90-Day Standard", desc: "OEM intake and exhaust camshafts with lobe condition inspected." },
  { id: "connecting-rod", name: "Connecting Rod", system: "Engine & Drivetrain", sysCode: "01", slug: "engine", difficulty: "Advanced", warranty: "90-Day Standard", desc: "OEM forged or cast connecting rods matched to engine specs." },
  { id: "intake-manifold", name: "Intake Manifold", system: "Engine & Drivetrain", sysCode: "01", slug: "engine", difficulty: "Moderate", warranty: "90-Day Standard", desc: "Plenum and runner assembly verified for cracks, runner valves, and mating surfaces." },
  { id: "exhaust-manifold", name: "Exhaust Manifold", system: "Engine & Drivetrain", sysCode: "01", slug: "engine", difficulty: "Moderate", warranty: "90-Day Standard", desc: "Cast or tubular exhaust manifold checked for thermal cracks and stud condition." },
  { id: "oil-pan", name: "Oil Pan", system: "Engine & Drivetrain", sysCode: "01", slug: "engine", difficulty: "Moderate", warranty: "90-Day Standard", desc: "Stamped steel or cast aluminum pan with intact drain threads and baffle." },
  { id: "valve-cover", name: "Valve Cover", system: "Engine & Drivetrain", sysCode: "01", slug: "engine", difficulty: "Easy", warranty: "90-Day Standard", desc: "OEM valve cover with breather ports and ignition coil mount bosses." },
  { id: "timing-cover", name: "Timing Cover", system: "Engine & Drivetrain", sysCode: "01", slug: "engine", difficulty: "Moderate", warranty: "90-Day Standard", desc: "Front engine cover protecting timing chain or belt assembly." },
  { id: "engine-mount", name: "Engine Mount", system: "Engine & Drivetrain", sysCode: "01", slug: "engine", difficulty: "Moderate", warranty: "90-Day Standard", desc: "Hydraulic or solid rubber vibration isolator bracket assembly." },
  { id: "turbocharger", name: "Turbocharger", system: "Engine & Drivetrain", sysCode: "01", slug: "engine", difficulty: "Advanced", warranty: "90-Day Standard", desc: "Exhaust-driven forced induction unit checked for shaft play, turbine fin integrity, and wastegate function." },
  { id: "supercharger", name: "Supercharger", system: "Engine & Drivetrain", sysCode: "01", slug: "engine", difficulty: "Advanced", warranty: "90-Day Standard", desc: "Belt-driven positive displacement or centrifugal supercharger assembly." },
  { id: "harmonic-balancer", name: "Harmonic Balancer", system: "Engine & Drivetrain", sysCode: "01", slug: "engine", difficulty: "Moderate", warranty: "90-Day Standard", desc: "Crankshaft damper pulley with bonded elastomeric ring inspected." },

  // 02 Transmission & Drivetrain (15)
  { id: "automatic-transmission", name: "Automatic Transmission", system: "Transmission & Powertrain", sysCode: "02", slug: "transmission", difficulty: "Advanced", warranty: "90-Day to 1-Year", desc: "Complete automatic transmission unit including case, valve body, and converter match verified by tag code." },
  { id: "manual-transmission", name: "Manual Transmission", system: "Transmission & Powertrain", sysCode: "02", slug: "transmission", difficulty: "Advanced", warranty: "90-Day Standard", desc: "Manual gearbox with smooth synchronizer engagement and input shaft integrity." },
  { id: "transmission-assembly", name: "Transmission Assembly", system: "Transmission & Powertrain", sysCode: "02", slug: "transmission", difficulty: "Advanced", warranty: "90-Day to 1-Year", desc: "Tested transmission assembly matched to vehicle VIN, drivetrain, and gear ratio." },
  { id: "transfer-case", name: "Transfer Case", system: "Transmission & Powertrain", sysCode: "02", slug: "transfer-case", difficulty: "Advanced", warranty: "90-Day Standard", desc: "4WD/AWD transfer unit checked for chain tension, shift motor operation, and fluid condition." },
  { id: "differential", name: "Differential", system: "Transmission & Powertrain", sysCode: "02", slug: "differential", difficulty: "Advanced", warranty: "90-Day Standard", desc: "Front or rear differential carrier assembly with ring and pinion backlash inspected." },
  { id: "front-axle-assembly", name: "Front Axle Assembly", system: "Transmission & Powertrain", sysCode: "02", slug: "differential", difficulty: "Advanced", warranty: "90-Day Standard", desc: "Complete front axle housing, carrier, and axle tubes for 4x4 and AWD vehicles." },
  { id: "rear-axle-assembly", name: "Rear Axle Assembly", system: "Transmission & Powertrain", sysCode: "02", slug: "differential", difficulty: "Advanced", warranty: "90-Day Standard", desc: "Solid or independent rear axle carrier assembly with gear ratio match confirmed." },
  { id: "axle-shaft", name: "Axle Shaft", system: "Transmission & Powertrain", sysCode: "02", slug: "differential", difficulty: "Moderate", warranty: "90-Day Standard", desc: "Hardened steel drive axle shaft with splines and wheel flange verified true." },
  { id: "cv-axle", name: "CV Axle", system: "Transmission & Powertrain", sysCode: "02", slug: "transmission", difficulty: "Moderate", warranty: "90-Day Standard", desc: "Constant velocity axle shaft with intact boots and tight joint tolerances." },
  { id: "driveshaft", name: "Driveshaft", system: "Transmission & Powertrain", sysCode: "02", slug: "transmission", difficulty: "Moderate", warranty: "90-Day Standard", desc: "Balanced propeller shaft assembly with carrier bearings and U-joints." },
  { id: "torque-converter", name: "Torque Converter", system: "Transmission & Powertrain", sysCode: "02", slug: "transmission", difficulty: "Moderate", warranty: "90-Day Standard", desc: "Hydraulic fluid coupling matched to engine torque curve and transmission stator." },
  { id: "flywheel", name: "Flywheel", system: "Transmission & Powertrain", sysCode: "02", slug: "transmission", difficulty: "Moderate", warranty: "90-Day Standard", desc: "Manual transmission friction disc surface and ring gear teeth inspected." },
  { id: "flexplate", name: "Flexplate", system: "Transmission & Powertrain", sysCode: "02", slug: "transmission", difficulty: "Moderate", warranty: "90-Day Standard", desc: "Automatic transmission drive plate checked for cracking and starter ring gear wear." },
  { id: "clutch-assembly", name: "Clutch Assembly", system: "Transmission & Powertrain", sysCode: "02", slug: "transmission", difficulty: "Moderate", warranty: "90-Day Standard", desc: "Pressure plate, clutch disc, and release fork mechanism." },
  { id: "transmission-control-module", name: "Transmission Control Module", system: "Transmission & Powertrain", sysCode: "02", slug: "transmission", difficulty: "Moderate", warranty: "90-Day Standard", desc: "TCM unit programmed for transmission solenoid sequencing and shift maps." },

  // 03 Body & Exterior (17)
  { id: "front-bumper", name: "Front Bumper", system: "Body & Exterior", sysCode: "03", slug: "front-bumper", difficulty: "Moderate", warranty: "Fitment Guarantee", desc: "Front bumper face bar or complete assembly matched to vehicle trim and fog lamp cutouts." },
  { id: "rear-bumper", name: "Rear Bumper", system: "Body & Exterior", sysCode: "03", slug: "front-bumper", difficulty: "Moderate", warranty: "Fitment Guarantee", desc: "Rear step bumper or bumper assembly with backup sensor provisions." },
  { id: "bumper-cover", name: "Bumper Cover", system: "Body & Exterior", sysCode: "03", slug: "front-bumper", difficulty: "Moderate", warranty: "Fitment Guarantee", desc: "Fascia shell inspected for mounting tab integrity and grille alignment." },
  { id: "bumper-assembly", name: "Bumper Assembly", system: "Body & Exterior", sysCode: "03", slug: "front-bumper", difficulty: "Moderate", warranty: "Fitment Guarantee", desc: "Complete unit including reinforcement beam, impact absorbers, and cover." },
  { id: "fender", name: "Fender", system: "Body & Exterior", sysCode: "03", slug: "front-bumper", difficulty: "Moderate", warranty: "Fitment Guarantee", desc: "Left or right front quarter sheet metal panel matched to wheel opening and lamp pockets." },
  { id: "hood", name: "Hood", system: "Body & Exterior", sysCode: "03", slug: "front-bumper", difficulty: "Moderate", warranty: "Fitment Guarantee", desc: "Engine hood panel checked for hinge straightness, latch loop, and skin seams." },
  { id: "front-door", name: "Front Door", system: "Body & Exterior", sysCode: "03", slug: "front-bumper", difficulty: "Moderate", warranty: "Fitment Guarantee", desc: "Driver or passenger front door shell with hinge pins and lock mechanisms." },
  { id: "rear-door", name: "Rear Door", system: "Body & Exterior", sysCode: "03", slug: "front-bumper", difficulty: "Moderate", warranty: "Fitment Guarantee", desc: "Rear passenger door shell matched to sedan, SUV, or crew cab body configurations." },
  { id: "trunk-lid", name: "Trunk Lid", system: "Body & Exterior", sysCode: "03", slug: "front-bumper", difficulty: "Moderate", warranty: "Fitment Guarantee", desc: "Decklid panel with spoiler options, camera holes, and latch alignment." },
  { id: "tailgate", name: "Tailgate", system: "Body & Exterior", sysCode: "03", slug: "front-bumper", difficulty: "Moderate", warranty: "Fitment Guarantee", desc: "Pickup truck tailgate with torsion bar, latch handle, and reverse camera provision." },
  { id: "liftgate", name: "Liftgate", system: "Body & Exterior", sysCode: "03", slug: "front-bumper", difficulty: "Moderate", warranty: "Fitment Guarantee", desc: "SUV / hatchback rear door with power actuator and wiper motor provisions." },
  { id: "grille", name: "Grille", system: "Body & Exterior", sysCode: "03", slug: "front-bumper", difficulty: "Easy", warranty: "Fitment Guarantee", desc: "Front radiator grille with emblem mount and active shutter provisions." },
  { id: "side-mirror", name: "Side Mirror", system: "Body & Exterior", sysCode: "03", slug: "front-bumper", difficulty: "Easy", warranty: "90-Day Standard", desc: "Power, heated, blind-spot detection, or folding side view mirror assembly." },
  { id: "radiator-support", name: "Radiator Support", system: "Body & Exterior", sysCode: "03", slug: "front-bumper", difficulty: "Advanced", warranty: "Fitment Guarantee", desc: "Core support frame holding cooling module, headlamps, and latch." },
  { id: "quarter-panel", name: "Quarter Panel", system: "Body & Exterior", sysCode: "03", slug: "front-bumper", difficulty: "Advanced", warranty: "Fitment Guarantee", desc: "Rear body quarter panel section cut to repair shop specifications." },
  { id: "window-regulator", name: "Window Regulator", system: "Body & Exterior", sysCode: "03", slug: "front-bumper", difficulty: "Moderate", warranty: "90-Day Standard", desc: "Scissor or cable door glass lifting track mechanism." },
  { id: "door-handle", name: "Door Handle", system: "Body & Exterior", sysCode: "03", slug: "front-bumper", difficulty: "Easy", warranty: "90-Day Standard", desc: "Interior or exterior door handle with keyless sensor or lock rod clip." },

  // 04 Electrical Components (12)
  { id: "alternator", name: "Alternator", system: "Electrical & Lighting", sysCode: "04", slug: "alternator", difficulty: "Moderate", warranty: "90-Day to 1-Year", desc: "High-output charging generator bench-tested for diode ripple and voltage regulation." },
  { id: "starter-motor", name: "Starter Motor", system: "Electrical & Lighting", sysCode: "04", slug: "alternator", difficulty: "Moderate", warranty: "90-Day to 1-Year", desc: "High-torque starter motor tested for solenoid throw and armature current draw." },
  { id: "engine-control-module", name: "Engine Control Module", system: "Electrical & Lighting", sysCode: "04", slug: "alternator", difficulty: "Moderate", warranty: "90-Day Standard", desc: "OEM ECU / ECM matched by part number and hardware revision." },
  { id: "powertrain-control-module", name: "Powertrain Control Module", system: "Electrical & Lighting", sysCode: "04", slug: "alternator", difficulty: "Moderate", warranty: "90-Day Standard", desc: "Integrated engine and transmission computer unit." },
  { id: "wiring-harness", name: "Wiring Harness", system: "Electrical & Lighting", sysCode: "04", slug: "alternator", difficulty: "Advanced", warranty: "90-Day Standard", desc: "Engine bay, dash, or chassis harness with uncut connectors." },
  { id: "fuse-box", name: "Fuse Box", system: "Electrical & Lighting", sysCode: "04", slug: "alternator", difficulty: "Moderate", warranty: "90-Day Standard", desc: "Totally integrated power module (TIPM) or underhood junction box." },
  { id: "ignition-coil", name: "Ignition Coil", system: "Electrical & Lighting", sysCode: "04", slug: "alternator", difficulty: "Easy", warranty: "90-Day Standard", desc: "Coil-on-plug or multi-pack ignition transformer." },
  { id: "instrument-cluster", name: "Instrument Cluster", system: "Electrical & Lighting", sysCode: "04", slug: "alternator", difficulty: "Moderate", warranty: "90-Day Standard", desc: "Digital or analog gauge cluster matched to vehicle options." },
  { id: "window-switch", name: "Window Switch", system: "Electrical & Lighting", sysCode: "04", slug: "alternator", difficulty: "Easy", warranty: "90-Day Standard", desc: "Master driver door window and lock switch cluster." },
  { id: "power-window-motor", name: "Power Window Motor", system: "Electrical & Lighting", sysCode: "04", slug: "alternator", difficulty: "Moderate", warranty: "90-Day Standard", desc: "Reversible DC electric motor driving window lift track." },
  { id: "body-control-module", name: "Body Control Module", system: "Electrical & Lighting", sysCode: "04", slug: "alternator", difficulty: "Moderate", warranty: "90-Day Standard", desc: "BCM controlling lighting, door locks, alarm, and comfort convenience." },
  { id: "electronic-sensors", name: "Various Electronic Sensors", system: "Electrical & Lighting", sysCode: "04", slug: "alternator", difficulty: "Easy", warranty: "90-Day Standard", desc: "Mass air flow, crankshaft position, camshaft position, and manifold sensors." },

  // 05 Headlights & Lighting (7)
  { id: "headlight-assembly", name: "Headlight Assembly", system: "Electrical & Lighting", sysCode: "05", slug: "headlight", difficulty: "Moderate", warranty: "Fitment Guarantee", desc: "Halogen, Xenon HID, or full LED headlamp assembly with intact housing tabs and clear lens." },
  { id: "tail-light-assembly", name: "Tail Light Assembly", system: "Electrical & Lighting", sysCode: "05", slug: "headlight", difficulty: "Easy", warranty: "Fitment Guarantee", desc: "Rear quarter or trunk-mounted tail lamp housing with intact wiring." },
  { id: "fog-light", name: "Fog Light", system: "Electrical & Lighting", sysCode: "05", slug: "headlight", difficulty: "Easy", warranty: "Fitment Guarantee", desc: "Lower bumper mounted auxiliary driving or fog lamp unit." },
  { id: "turn-signal-light", name: "Turn Signal Light", system: "Electrical & Lighting", sysCode: "05", slug: "headlight", difficulty: "Easy", warranty: "Fitment Guarantee", desc: "Amber corner or bumper turn indicator light assembly." },
  { id: "daytime-running-light", name: "Daytime Running Light", system: "Electrical & Lighting", sysCode: "05", slug: "headlight", difficulty: "Easy", warranty: "Fitment Guarantee", desc: "Dedicated DRL light bar or bumper bezel assembly." },
  { id: "third-brake-light", name: "Third Brake Light", system: "Electrical & Lighting", sysCode: "05", slug: "headlight", difficulty: "Easy", warranty: "Fitment Guarantee", desc: "Center high-mounted stop light (CHMSL) with LED array tested." },
  { id: "headlight-control-module", name: "Headlight Control Module", system: "Electrical & Lighting", sysCode: "05", slug: "headlight", difficulty: "Easy", warranty: "90-Day Standard", desc: "Xenon ballast or adaptive LED curve lighting driver module." },

  // 06 Cooling & HVAC (10)
  { id: "radiator", name: "Radiator", system: "Cooling & HVAC", sysCode: "06", slug: "ac-compressor", difficulty: "Moderate", warranty: "90-Day Standard", desc: "Engine coolant heat exchanger pressure-tested for core and tank seal integrity." },
  { id: "radiator-fan", name: "Radiator Fan", system: "Cooling & HVAC", sysCode: "06", slug: "ac-compressor", difficulty: "Moderate", warranty: "90-Day Standard", desc: "Electric cooling fan motor and blade assembly." },
  { id: "cooling-fan-assembly", name: "Cooling Fan Assembly", system: "Cooling & HVAC", sysCode: "06", slug: "ac-compressor", difficulty: "Moderate", warranty: "90-Day Standard", desc: "Dual fan shroud assembly with integrated control module." },
  { id: "ac-compressor", name: "AC Compressor", system: "Cooling & HVAC", sysCode: "06", slug: "ac-compressor", difficulty: "Advanced", warranty: "90-Day to 1-Year", desc: "Air conditioning pump tested for magnetic clutch engagement, shaft turn, and suction/discharge pressure." },
  { id: "ac-condenser", name: "AC Condenser", system: "Cooling & HVAC", sysCode: "06", slug: "ac-compressor", difficulty: "Moderate", warranty: "90-Day Standard", desc: "High-pressure refrigerant condenser mounted forward of radiator." },
  { id: "heater-core", name: "Heater Core", system: "Cooling & HVAC", sysCode: "06", slug: "ac-compressor", difficulty: "Advanced", warranty: "90-Day Standard", desc: "Cabin heat exchanger checked for fin blockage and tube corrosion." },
  { id: "blower-motor", name: "Blower Motor", system: "Cooling & HVAC", sysCode: "06", slug: "ac-compressor", difficulty: "Easy", warranty: "90-Day Standard", desc: "HVAC cabin ventilation fan motor with squirrel cage impeller." },
  { id: "water-pump", name: "Water Pump", system: "Cooling & HVAC", sysCode: "06", slug: "ac-compressor", difficulty: "Moderate", warranty: "90-Day Standard", desc: "Mechanical or auxiliary electric engine coolant circulation pump." },
  { id: "thermostat-housing", name: "Thermostat Housing", system: "Cooling & HVAC", sysCode: "06", slug: "ac-compressor", difficulty: "Easy", warranty: "90-Day Standard", desc: "Coolant outlet neck or electronic thermostat housing assembly." },
  { id: "intercooler", name: "Intercooler", system: "Cooling & HVAC", sysCode: "06", slug: "ac-compressor", difficulty: "Moderate", warranty: "90-Day Standard", desc: "Turbo/supercharger charge air cooler inspected for boost leak." },

  // 07 Steering & Suspension (10)
  { id: "steering-rack", name: "Steering Rack", system: "Steering & Suspension", sysCode: "07", slug: "steering-rack", difficulty: "Advanced", warranty: "90-Day to 1-Year", desc: "Hydraulic or electric power steering rack and pinion with tie rod threads inspected." },
  { id: "steering-column", name: "Steering Column", system: "Steering & Suspension", sysCode: "07", slug: "steering-rack", difficulty: "Advanced", warranty: "90-Day Standard", desc: "Tilt/telescoping steering shaft with ignition housing and intermediate shaft." },
  { id: "power-steering-pump", name: "Power Steering Pump", system: "Steering & Suspension", sysCode: "07", slug: "steering-rack", difficulty: "Moderate", warranty: "90-Day Standard", desc: "Belt-driven hydraulic pump or electric-hydraulic power steering unit." },
  { id: "control-arm", name: "Control Arm", system: "Steering & Suspension", sysCode: "07", slug: "steering-rack", difficulty: "Moderate", warranty: "90-Day Standard", desc: "Upper or lower A-arm with ball joint taper and bushings inspected." },
  { id: "steering-knuckle", name: "Steering Knuckle", system: "Steering & Suspension", sysCode: "07", slug: "steering-rack", difficulty: "Moderate", warranty: "90-Day Standard", desc: "Cast wheel spindle upright with brake caliper ears and strut mounts." },
  { id: "strut-assembly", name: "Strut Assembly", system: "Steering & Suspension", sysCode: "07", slug: "steering-rack", difficulty: "Moderate", warranty: "90-Day Standard", desc: "MacPherson strut damper with coil spring and top mount bearing." },
  { id: "shock-absorber", name: "Shock Absorber", system: "Steering & Suspension", sysCode: "07", slug: "steering-rack", difficulty: "Moderate", warranty: "90-Day Standard", desc: "Monotube or twin-tube suspension damper inspected for fluid leakage." },
  { id: "suspension-subframe", name: "Suspension Subframe", system: "Steering & Suspension", sysCode: "07", slug: "steering-rack", difficulty: "Advanced", warranty: "Fitment Guarantee", desc: "Front engine cradle or rear subframe crossmember checked true on frame jig." },
  { id: "sway-bar", name: "Sway Bar", system: "Steering & Suspension", sysCode: "07", slug: "steering-rack", difficulty: "Moderate", warranty: "90-Day Standard", desc: "Anti-roll stabilizer bar with link mounts and bushing collars." },
  { id: "tie-rod-assembly", name: "Tie Rod Assembly", system: "Steering & Suspension", sysCode: "07", slug: "steering-rack", difficulty: "Moderate", warranty: "90-Day Standard", desc: "Inner and outer tie rod ends with adjustment sleeve." },

  // 08 Braking & Wheel Components (7)
  { id: "brake-caliper", name: "Brake Caliper", system: "Braking Systems", sysCode: "08", slug: "brake-caliper", difficulty: "Moderate", warranty: "90-Day Standard", desc: "Front or rear hydraulic caliper with slide pins, piston seal, and bracket." },
  { id: "brake-booster", name: "Brake Booster", system: "Braking Systems", sysCode: "08", slug: "brake-caliper", difficulty: "Moderate", warranty: "90-Day Standard", desc: "Vacuum diaphragm or hydraulic brake power booster unit." },
  { id: "master-cylinder", name: "Master Cylinder", system: "Braking Systems", sysCode: "08", slug: "brake-caliper", difficulty: "Moderate", warranty: "90-Day Standard", desc: "Dual-circuit brake fluid master reservoir and piston cylinder." },
  { id: "abs-control-module", name: "ABS Control Module", system: "Braking Systems", sysCode: "08", slug: "brake-caliper", difficulty: "Moderate", warranty: "90-Day to 1-Year", desc: "Anti-lock brake hydraulic control unit and electronic solenoid module." },
  { id: "wheel-hub", name: "Wheel Hub", system: "Braking Systems", sysCode: "08", slug: "brake-caliper", difficulty: "Moderate", warranty: "90-Day Standard", desc: "Hub assembly with wheel studs and integrated speed sensor ring." },
  { id: "wheel-bearing", name: "Wheel Bearing", system: "Braking Systems", sysCode: "08", slug: "brake-caliper", difficulty: "Moderate", warranty: "90-Day Standard", desc: "Press-in or bolt-on unit bearing tested for zero radial runout." },
  { id: "wheel-rim", name: "Wheel Rim", system: "Braking Systems", sysCode: "08", slug: "brake-caliper", difficulty: "Easy", warranty: "Fitment Guarantee", desc: "OEM alloy or steel wheel checked for roundness, crack absence, and lug bore fit." },

  // 09 Interior Components (8)
  { id: "front-seat", name: "Front Seat", system: "Interior Components", sysCode: "09", slug: "part-detail", difficulty: "Moderate", warranty: "Fitment Guarantee", desc: "Driver or passenger bucket seat with power tracks and airbag modules." },
  { id: "rear-seat", name: "Rear Seat", system: "Interior Components", sysCode: "09", slug: "part-detail", difficulty: "Moderate", warranty: "Fitment Guarantee", desc: "Bench or split-folding 60/40 rear seat matched to upholstery color code." },
  { id: "dashboard", name: "Dashboard", system: "Interior Components", sysCode: "09", slug: "part-detail", difficulty: "Advanced", warranty: "Fitment Guarantee", desc: "Main instrument panel pad and frame assembly." },
  { id: "center-console", name: "Center Console", system: "Interior Components", sysCode: "09", slug: "part-detail", difficulty: "Easy", warranty: "Fitment Guarantee", desc: "Floor console with armrest lid, cupholders, and shifter bezel." },
  { id: "door-panel", name: "Door Panel", system: "Interior Components", sysCode: "09", slug: "part-detail", difficulty: "Easy", warranty: "Fitment Guarantee", desc: "Interior door card upholstery matched to cabin trim code." },
  { id: "infotainment-unit", name: "Infotainment Unit", system: "Interior Components", sysCode: "09", slug: "part-detail", difficulty: "Moderate", warranty: "90-Day Standard", desc: "Touchscreen radio, navigation, and audio receiver display." },
  { id: "climate-control-panel", name: "Climate Control Panel", system: "Interior Components", sysCode: "09", slug: "part-detail", difficulty: "Easy", warranty: "90-Day Standard", desc: "Automatic or manual AC heater control faceplate switch." },
  { id: "interior-trim-components", name: "Interior Trim Components", system: "Interior Components", sysCode: "09", slug: "part-detail", difficulty: "Easy", warranty: "Fitment Guarantee", desc: "Pillar trim, sill plates, dash vents, and console garnish." }
];

document.addEventListener("DOMContentLoaded", () => {
  initMobileNav();
  populateDropdowns();
  setupDatalists();
  setupFormPrefill();
  setupFormSubmissions();
  setupCategoryButtons();
  setupFaqSearch();
  setupMakePills();
  setupCatalogInteractivity();
  setupModalDismissal();
  setupPartDetailPage();
  setupUcpDirectoryInteractivity();
  initFixedCallButton();
});

// Mobile navigation toggle
function initMobileNav() {
  const toggleBtn = document.querySelector(".menu-toggle");
  const mobileNav = document.getElementById("mobile-navigation");
  if (!toggleBtn || !mobileNav) return;

  toggleBtn.addEventListener("click", () => {
    const isExpanded = toggleBtn.getAttribute("aria-expanded") === "true";
    toggleBtn.setAttribute("aria-expanded", !isExpanded);
    toggleBtn.classList.toggle("open", !isExpanded);
    mobileNav.classList.toggle("open", !isExpanded);
    mobileNav.removeAttribute("inert");
    if (isExpanded) {
      mobileNav.setAttribute("inert", "");
    }
  });

  // Close mobile nav when clicking a link
  mobileNav.querySelectorAll("a").forEach(link => {
    link.addEventListener("click", () => {
      toggleBtn.setAttribute("aria-expanded", "false");
      toggleBtn.classList.remove("open");
      mobileNav.classList.remove("open");
      mobileNav.setAttribute("inert", "");
    });
  });
}

// Populate Year Selects (2026 down to 1980)
function populateDropdowns() {
  const yearSelects = document.querySelectorAll("select[name='year']");
  yearSelects.forEach(sel => {
    if (sel.options.length <= 1) {
      for (let y = 2026; y >= 1980; y--) {
        const opt = document.createElement("option");
        opt.value = y.toString();
        opt.textContent = y.toString();
        sel.appendChild(opt);
      }
    }
  });
}

// Populate Make & Part Datalists
function setupDatalists() {
  document.querySelectorAll("datalist[id$='-makes']").forEach(dl => {
    if (dl.children.length === 0) {
      VEHICLE_MAKES.forEach(m => {
        const opt = document.createElement("option");
        opt.value = m;
        dl.appendChild(opt);
      });
    }
  });

  document.querySelectorAll("datalist[id$='-parts']").forEach(dl => {
    if (dl.children.length === 0) {
      AUTO_PARTS_CATALOG.forEach(p => {
        const opt = document.createElement("option");
        opt.value = p.name;
        dl.appendChild(opt);
      });
    }
  });
}

// Prefill form from URL query parameters (e.g. ?part=Engine&make=Ford)
function setupFormPrefill() {
  const params = new URLSearchParams(window.location.search);
  const partParam = params.get("part");
  const makeParam = params.get("make");
  const modelParam = params.get("model");
  const yearParam = params.get("year");

  if (partParam) {
    document.querySelectorAll("input[name='part']").forEach(i => i.value = partParam);
  }
  if (makeParam) {
    document.querySelectorAll("input[name='make']").forEach(i => i.value = makeParam);
  }
  if (modelParam) {
    document.querySelectorAll("input[name='model']").forEach(i => i.value = modelParam);
  }
  if (yearParam) {
    document.querySelectorAll("select[name='year']").forEach(i => i.value = yearParam);
  }
}

// Setup pure HTML/CSS/JavaScript form submission
function setupFormSubmissions() {
  document.querySelectorAll("form").forEach(form => {
    // Only handle part request forms
    if (!form.querySelector("input[name='part']") && !form.querySelector("input[name='phone']")) return;

    form.addEventListener("submit", (e) => {
      e.preventDefault();

      // 1. Honeypot check (anti-bot)
      const honeypot = form.querySelector("input[name='company_website']");
      if (honeypot && honeypot.value.trim() !== "") {
        console.warn("Spam submission prevented by honeypot.");
        return;
      }

      // 2. Extract values
      const year = form.querySelector("select[name='year']")?.value || "Unspecified Year";
      const make = form.querySelector("input[name='make']")?.value.trim() || "Vehicle";
      const model = form.querySelector("input[name='model']")?.value.trim() || "";
      const part = form.querySelector("input[name='part']")?.value.trim() || "Automotive Replacement Part";
      const zip = form.querySelector("input[name='zip']")?.value.trim() || "Nationwide Delivery";
      const name = form.querySelector("input[name='name']")?.value.trim() || "Valued Customer";
      const phoneInput = form.querySelector("input[name='phone']");
      const phone = phoneInput?.value.trim() || "";
      const emailInput = form.querySelector("input[name='email']");
      const email = emailInput?.value.trim() || "";
      const vinInput = form.querySelector("input[name='vin']");
      const vin = vinInput?.value.trim().toUpperCase() || "";
      const notes = form.querySelector("textarea[name='notes']")?.value.trim() || "";

      // 3. Front-end Validation
      if (!phone) {
        showToast("Please provide a contact phone number so our team can follow up.");
        phoneInput?.focus();
        return;
      }

      if (email && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
        showToast("Please provide a valid email address.");
        emailInput?.focus();
        return;
      }

      if (vin && vin.length !== 17) {
        showToast("VIN must be exactly 17 characters if provided.");
        vinInput?.focus();
        return;
      }

      // 4. Submit button feedback animation
      const submitBtn = form.querySelector("button[type='submit']");
      const originalBtnText = submitBtn ? submitBtn.innerHTML : "";
      if (submitBtn) {
        submitBtn.disabled = true;
        submitBtn.innerHTML = `<span>Submitting request...</span>`;
      }

      // 5. Generate Reference ID & Vehicle description
      const reqId = "DS-" + Math.floor(100000 + Math.random() * 900000);
      const vehicleDesc = `${year} ${make} ${model}`.trim();

      // 6. Save locally in browser localStorage (no backend server required)
      const submission = {
        reqId,
        date: new Date().toISOString(),
        year,
        make,
        model,
        vehicleDesc,
        part,
        vin,
        zip,
        name,
        phone,
        email,
        notes
      };

      try {
        const stored = JSON.parse(localStorage.getItem("doorstep_requests") || "[]");
        stored.unshift(submission);
        localStorage.setItem("doorstep_requests", JSON.stringify(stored));
      } catch (err) {
        console.warn("Could not save to localStorage:", err);
      }

      // 7. Complete submission & display confirmation modal
      setTimeout(() => {
        if (submitBtn) {
          submitBtn.disabled = false;
          submitBtn.innerHTML = originalBtnText;
        }

        showConfirmationModal({
          reqId,
          vehicleDesc,
          part,
          zip,
          name,
          phone
        });

        form.reset();
      }, 450);
    });
  });

  // Global helper to view submissions in browser console (press F12 -> Console -> getPartRequests())
  window.getPartRequests = function() {
    const list = JSON.parse(localStorage.getItem("doorstep_requests") || "[]");
    console.table(list);
    return list;
  };
  window.clearPartRequests = function() {
    localStorage.removeItem("doorstep_requests");
    console.log("All saved part requests cleared.");
  };
}

// Confirmation modal builder & display
function showConfirmationModal({ reqId, vehicleDesc, part, zip, name, phone }) {
  let modalBackdrop = document.getElementById("quote-confirmation-modal");
  if (!modalBackdrop) {
    modalBackdrop = document.createElement("div");
    modalBackdrop.id = "quote-confirmation-modal";
    modalBackdrop.className = "modal-backdrop";
    document.body.appendChild(modalBackdrop);
  }

  modalBackdrop.innerHTML = `
    <div class="modal-content" role="dialog" aria-modal="true" aria-labelledby="modal-confirmed-title">
      <button class="modal-close" type="button" aria-label="Close modal">&times;</button>
      <div class="modal-badge">
        <svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="2.5"><polyline points="20 6 9 17 4 12"></polyline></svg>
        Part Request Received / In Review
      </div>
      <h2 id="modal-confirmed-title" class="modal-title">Your search is in motion.</h2>
      <p class="modal-desc">
        Thank you, <strong>${escapeHtml(name)}</strong>. Our specialized sourcing team has logged your vehicle specifications and is checking verified OEM recyclers across the U.S.
      </p>

      <div class="modal-info-card">
        <div class="modal-info-item">
          <small>Reference Number</small>
          <strong>${reqId}</strong>
        </div>
        <div class="modal-info-item">
          <small>Destination ZIP</small>
          <strong>${escapeHtml(zip)}</strong>
        </div>
        <div class="modal-info-item" style="grid-column: span 2;">
          <small>Requested Component</small>
          <strong style="color: #225bd6;">${escapeHtml(part)}</strong>
        </div>
        <div class="modal-info-item" style="grid-column: span 2;">
          <small>Target Vehicle</small>
          <strong>${escapeHtml(vehicleDesc)}</strong>
        </div>
      </div>

      <p style="font-size: 0.85rem; color: #52696f; margin-bottom: 1.5rem; line-height: 1.5;">
        A parts specialist will review compatibility (VIN, donor grade, mileage, warranty) and reach out to you at <strong>${escapeHtml(phone)}</strong> to discuss verified options before any order is placed.
      </p>

      <div class="modal-actions">
        <a href="tel:+18888790515" class="button button-blue" style="display:inline-flex; align-items:center; gap:0.5rem;">
          <svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="1.5"><path d="M7 3h3l1.2 4.1-2 1.7a15.5 15.5 0 0 0 6 6l1.7-2L21 14v3a4 4 0 0 1-4 4A14 14 0 0 1 3 7a4 4 0 0 1 4-4Z"></path></svg>
          Call Specialist Now: (888) 879-0515
        </a>
        <button type="button" class="button button-text-light modal-dismiss-btn" style="background:#eef4f3; color:#153b43; border:1px solid #c9d6d4;">Done</button>
      </div>
    </div>
  `;

  setTimeout(() => modalBackdrop.classList.add("active"), 10);

  modalBackdrop.querySelector(".modal-close").addEventListener("click", () => {
    modalBackdrop.classList.remove("active");
  });
  modalBackdrop.querySelector(".modal-dismiss-btn").addEventListener("click", () => {
    modalBackdrop.classList.remove("active");
  });
}

function setupModalDismissal() {
  document.addEventListener("keydown", (e) => {
    if (e.key === "Escape") {
      document.querySelectorAll(".modal-backdrop.active").forEach(m => m.classList.remove("active"));
    }
  });

  document.addEventListener("click", (e) => {
    if (e.target.classList.contains("modal-backdrop")) {
      e.target.classList.remove("active");
    }
  });
}

// Setup popular parts category buttons (Homepage)
function setupCategoryButtons() {
  // If .category elements are anchor links (<a>), allow normal navigation to the part pages!
  document.querySelectorAll('a.category').forEach(link => {
    // Natural navigation to part detail page
  });
  const categoryMap = {
    "category-1": "Engine",
    "category-2": "Transmission",
    "category-3": "Front Bumper",
    "category-4": "Alternator",
    "category-5": "AC Compressor",
    "category-6": "Steering Rack",
    "category-7": "Brake Caliper"
  };

  Object.entries(categoryMap).forEach(([className, partName]) => {
    document.querySelectorAll(`.${className}`).forEach(btn => {
      btn.addEventListener("click", () => {
        const partInput = document.querySelector("#part-needed, input[name='part']");
        if (partInput) {
          partInput.value = partName;
          const target = document.getElementById("request") || document.getElementById("used-parts-request") || partInput;
          target.scrollIntoView({ behavior: "smooth" });
          partInput.focus();
          showToast(`Selected "${partName}" — enter your vehicle details below.`);
        } else {
          const isSubdir = window.location.pathname.includes('/parts/') || window.location.pathname.includes('/blog/');
          const prefix = isSubdir ? '../' : '';
          window.location.href = `${prefix}find-a-part.html?part=${encodeURIComponent(partName)}`;
        }
      });
    });
  });
}

// Live search for FAQ page
function setupFaqSearch() {
  const searchInput = document.getElementById("faq-search");
  if (!searchInput) return;

  const faqItems = document.querySelectorAll("[data-faq-item='true']");
  const statusEl = document.querySelector(".faq-search-status");

  searchInput.addEventListener("input", () => {
    const query = searchInput.value.toLowerCase().trim();
    let matchCount = 0;

    faqItems.forEach(item => {
      const summaryText = item.querySelector("summary")?.textContent.toLowerCase() || "";
      const bodyText = item.querySelector(".faq-answer-body")?.textContent.toLowerCase() || "";
      const isMatch = !query || summaryText.includes(query) || bodyText.includes(query);

      if (isMatch) {
        item.style.display = "";
        matchCount++;
        if (query.length > 2) {
          item.setAttribute("open", "");
        }
      } else {
        item.style.display = "none";
        item.removeAttribute("open");
      }
    });

    if (statusEl) {
      statusEl.textContent = query 
        ? `Showing ${matchCount} of ${faqItems.length} answers for "${query}"`
        : `Showing all ${faqItems.length} answers`;
    }
  });
}

// Setup Make pills
function setupMakePills() {
  document.querySelectorAll(".make-pill-btn").forEach(btn => {
    btn.addEventListener("click", () => {
      const make = btn.dataset.make || btn.textContent.trim();
      const makeInput = document.querySelector("input[name='make']");
      if (makeInput) {
        makeInput.value = make;
        const modelInput = document.querySelector("input[name='model']");
        if (modelInput) modelInput.focus();
        showToast(`Vehicle make set to ${make}.`);
        const target = document.getElementById("used-parts-request") || document.getElementById("request");
        if (target) target.scrollIntoView({ behavior: "smooth" });
      }
    });
  });
}

// Catalog interactivity on used-car-parts.html and all-parts.html
function setupCatalogInteractivity() {
  const catalogSearch = document.getElementById("catalog-search");
  const catalogList = document.querySelectorAll(".part-card-pro, .directory-part-item");
  const countEl = document.getElementById("catalog-match-count");

  if (catalogSearch && catalogList.length > 0) {
    catalogSearch.addEventListener("input", () => {
      const q = catalogSearch.value.toLowerCase().trim();
      let matches = 0;

      catalogList.forEach(el => {
        const text = el.textContent.toLowerCase();
        if (!q || text.includes(q)) {
          el.style.display = "";
          matches++;
        } else {
          el.style.display = "none";
        }
      });

      if (countEl) {
        countEl.textContent = `${matches} Parts Available`;
      }
    });
  }
}

// Show subtle toast banner
function showToast(msg) {
  let toast = document.getElementById("app-toast");
  if (!toast) {
    toast = document.createElement("div");
    toast.id = "app-toast";
    toast.className = "toast-notice";
    document.body.appendChild(toast);
  }

  toast.innerHTML = `
    <svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="#91b8ff" stroke-width="2"><circle cx="12" cy="12" r="10"></circle><line x1="12" y1="16" x2="12" y2="12"></line><line x1="12" y1="8" x2="12.01" y2="8"></line></svg>
    <span>${escapeHtml(msg)}</span>
  `;

  toast.classList.add("show");
  clearTimeout(toast._timeout);
  toast._timeout = setTimeout(() => {
    toast.classList.remove("show");
  }, 4000);
}

function escapeHtml(str) {
  return String(str).replace(/[&<>"']/g, m => ({
    "&": "&amp;",
    "<": "&lt;",
    ">": "&gt;",
    '"': "&quot;",
    "'": "&#39;"
  }[m]));
}

// Setup dynamic part detail viewer (for parts/part-detail.html)
function setupPartDetailPage() {
  if (!document.querySelector(".part-page-detail")) return;
  const params = new URLSearchParams(window.location.search);
  const partParam = params.get("part") || params.get("name") || params.get("id");
  if (!partParam) return;

  const found = AUTO_PARTS_CATALOG.find(p => 
    p.name.toLowerCase() === partParam.toLowerCase() || 
    p.id.toLowerCase() === partParam.toLowerCase()
  ) || {
    name: partParam,
    system: "Automotive Component",
    sysCode: "00",
    desc: `OEM replacement ${partParam} sourced from verified automotive recyclers across the USA.`
  };

  const titleEl = document.querySelector(".part-detail-hero h1");
  if (titleEl) {
    titleEl.innerHTML = `${escapeHtml(found.name.toUpperCase())}<br/><em style="color:#91b8ff; font-style:normal;">OEM &amp; REPLACEMENT.</em>`;
  }
  const descEl = document.querySelector(".part-detail-hero p");
  if (descEl && found.desc) {
    descEl.textContent = found.desc;
  }
  const schematicEl = document.getElementById("dynamic-schematic-ref");
  if (schematicEl) {
    schematicEl.textContent = `SCHEMATIC REF: ${found.sysCode || "00"}-OEM-${found.name.toUpperCase().replace(/\s+/g, '-')}`;
  }
  const reqBtn = document.querySelector(".part-detail-hero a.button-blue");
  if (reqBtn) {
    reqBtn.href = `../find-a-part.html?part=${encodeURIComponent(found.name)}`;
    reqBtn.innerHTML = `Request ${escapeHtml(found.name)} Availability <svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="2"><path d="M4 12h15m-6-6 6 6-6 6"></path></svg>`;
  }
  document.title = `${found.name} Online Across the USA | Doorstep Auto Parts`;
}

// Setup "A Practical Used Auto Parts Directory" on used-car-parts.html
function setupUcpDirectoryInteractivity() {
  const directoryTool = document.querySelector(".ucp-directory-tool");
  if (!directoryTool) return;

  const searchInput = directoryTool.querySelector(".ucp-search-input input");
  const filterButtons = directoryTool.querySelectorAll(".ucp-filters button");
  const statusEl = document.querySelector(".ucp-directory-status span:first-child");
  const statusHintEl = document.querySelector(".ucp-directory-status span:last-child");
  const groups = document.querySelectorAll(".ucp-directory-group");

  const systemMap = {
    "all parts": "all",
    "engine & drivetrain": "parts-engine",
    "transmission & powertrain": "parts-transmission",
    "body & exterior": "parts-body-exterior",
    "electrical components": "parts-electrical",
    "headlights & lighting": "parts-lighting",
    "cooling & hvac": "parts-cooling-hvac",
    "steering & suspension": "parts-steering-suspension",
    "brakes & wheels": "parts-braking-wheels",
    "interior components": "parts-interior"
  };

  let activeSystem = "all";

  function applyFilters() {
    const query = searchInput ? searchInput.value.toLowerCase().trim() : "";
    let visibleCount = 0;

    groups.forEach(group => {
      const groupId = group.id;
      const isSystemMatch = activeSystem === "all" || groupId === activeSystem;

      if (!isSystemMatch) {
        group.style.display = "none";
        return;
      }

      // Filter individual items within this matching group
      const items = group.querySelectorAll(".ucp-part-list li");
      let groupMatchCount = 0;

      items.forEach(li => {
        const text = li.textContent.toLowerCase();
        const matchesQuery = !query || text.includes(query);

        if (matchesQuery) {
          li.style.display = "";
          groupMatchCount++;
          visibleCount++;
        } else {
          li.style.display = "none";
        }
      });

      if (groupMatchCount > 0) {
        group.style.display = "";
        // Open details accordion if actively searching or filtering a single category
        if (query || activeSystem !== "all") {
          group.setAttribute("open", "");
        }
      } else {
        group.style.display = "none";
      }
    });

    // Update status counters
    if (statusEl) {
      if (query) {
        statusEl.textContent = `${visibleCount} part${visibleCount === 1 ? '' : 's'} matching "${query}"`;
      } else if (activeSystem !== "all") {
        statusEl.textContent = `${visibleCount} parts shown`;
      } else {
        statusEl.textContent = "102 parts shown";
      }
    }

    if (statusHintEl) {
      if (visibleCount === 0) {
        statusHintEl.textContent = 'No matching parts found. Try a different search term or click "All parts".';
      } else {
        statusHintEl.textContent = "Call (888) 879-0515 or click Call Now for immediate pricing.";
      }
    }
  }

  // 1. Filter buttons event listeners
  filterButtons.forEach(btn => {
    btn.addEventListener("click", () => {
      filterButtons.forEach(b => {
        b.setAttribute("aria-pressed", "false");
        b.classList.remove("active");
      });
      btn.setAttribute("aria-pressed", "true");
      btn.classList.add("active");

      const label = btn.textContent.toLowerCase().trim();
      activeSystem = systemMap[label] || "all";
      applyFilters();
    });
  });

  // 2. Search input event listener
  if (searchInput) {
    searchInput.addEventListener("input", applyFilters);
    searchInput.addEventListener("keydown", (e) => {
      if (e.key === "Escape") {
        searchInput.value = "";
        applyFilters();
      }
    });
  }

  // 3. Call Now / Request button on each part item
  document.querySelectorAll(".ucp-part-list .ucp-call-btn, .ucp-part-list button").forEach(btn => {
    btn.addEventListener("click", () => {
      let partName = btn.getAttribute("aria-label")?.replace(/^(Call Now for|Request)\s+/i, "").trim();
      if (!partName) {
        const link = btn.closest("li")?.querySelector(".ucp-part-name-link");
        partName = link ? link.textContent.trim() : "Automotive Replacement Part";
      }

      // Prefill the part input on the page as well
      const partInput = document.querySelector("#part-needed, input[name='part']");
      if (partInput) {
        partInput.value = partName;
      }

      showToast(`Calling parts specialist for ${partName}: (888) 879-0515`);
    });
  });

  // 4. Handle initial anchor navigation (e.g., #parts-transmission)
  if (window.location.hash) {
    const hashId = window.location.hash.substring(1);
    const targetGroup = document.getElementById(hashId);
    if (targetGroup && targetGroup.classList.contains("ucp-directory-group")) {
      targetGroup.setAttribute("open", "");
      filterButtons.forEach(btn => {
        const key = btn.textContent.toLowerCase().trim();
        if (systemMap[key] === hashId) {
          filterButtons.forEach(b => b.setAttribute("aria-pressed", "false"));
          btn.setAttribute("aria-pressed", "true");
          activeSystem = hashId;
          applyFilters();
        }
      });
      setTimeout(() => {
        targetGroup.scrollIntoView({ behavior: "smooth" });
      }, 100);
    }
  }
}

// Fixed "Call Now" Floating Button & In-Footer CTA
function initFixedCallButton() {
  if (document.querySelector(".fixed-call-widget")) return;

  const widget = document.createElement("aside");
  widget.className = "fixed-call-widget";
  widget.setAttribute("aria-label", "Immediate phone consultation");
  widget.innerHTML = `
    <a href="tel:+18888790515" class="fixed-call-btn" aria-label="Call Doorstep Auto Parts Now at (888) 879-0515">
      <span class="fixed-call-pulse" aria-hidden="true"></span>
      <span class="fixed-call-icon-wrap" aria-hidden="true">
        <svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
          <path d="M7 3h3l1.2 4.1-2 1.7a15.5 15.5 0 0 0 6 6l1.7-2L21 14v3a4 4 0 0 1-4 4A14 14 0 0 1 3 7a4 4 0 0 1 4-4Z"></path>
        </svg>
      </span>
      <span class="fixed-call-info">
        <span class="fixed-call-title">Call Now</span>
        <span class="fixed-call-number">(888) 879-0515</span>
      </span>
    </a>
  `;
  document.body.appendChild(widget);

  // Enhance all in-footer telephone links to have the prominent Call Now button
  document.querySelectorAll(".footer-contact a[href^='tel:']").forEach(link => {
    if (!link.classList.contains("footer-call-btn")) {
      link.classList.add("footer-call-btn");
      link.setAttribute("aria-label", "Call Doorstep Auto Parts at (888) 879-0515");
      link.innerHTML = `
        <svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" style="flex-shrink:0;">
          <path d="M7 3h3l1.2 4.1-2 1.7a15.5 15.5 0 0 0 6 6l1.7-2L21 14v3a4 4 0 0 1-4 4A14 14 0 0 1 3 7a4 4 0 0 1 4-4Z"></path>
        </svg>
        <span>Call Now: (888) 879-0515</span>
      `;
    }
  });
}
