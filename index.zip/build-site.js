const fs = require('fs');
const path = require('path');

const BRAIN_STEPS = 'C:/Users/rahul/.gemini/antigravity-ide/brain/06f8fa44-392d-4f24-b958-b71e21cdc35d/.system_generated/steps';

// Clean raw HTML from step dumps
function cleanHtml(rawHtml, depth = 0) {
  const prefix = depth === 1 ? '../' : depth === 2 ? '../../' : '';

  let html = rawHtml.slice(rawHtml.indexOf('<!DOCTYPE html>'));

  // Strip third party tracking/framework hydration scripts
  html = html.replace(/<script defer src="\/~flock\.js"[^>]*><\/script>/g, '');
  html = html.replace(/<script defer src="\/__l5e\/events\.[^>]*><\/script>/g, '');
  html = html.replace(/<script data-tsr-stream-part="">[\s\S]*?<\/script>/g, '');
  html = html.replace(/<script type="module" async="" src="\/assets\/index-[^>]*><\/script>/g, '');
  html = html.replace(/<script>document\.currentScript\.remove\(\);[\s\S]*?<\/script>/g, '');
  html = html.replace(/<script>\(function\(a,f\)[\s\S]*?<\/script>/g, '');

  // Fix assets to local
  html = html.replace(/href="\/assets\/styles-B6ITA7xY\.css"/g, `href="${prefix}assets/styles.css"`);
  html = html.replace(/href="\/brand\/favicon-option-b\.svg"/g, `href="${prefix}brand/favicon-option-b.svg"`);
  html = html.replace(/src="\/brand\/logo-selected-dark\.svg"/g, `src="${prefix}brand/logo-selected-dark.svg"`);
  html = html.replace(/src="\/brand\/bbb-logo-official\.svg"/g, `src="${prefix}brand/bbb-logo-official.svg"`);
  html = html.replace(/src="\/visuals\/brake-assembly\.svg"/g, `src="${prefix}visuals/brake-assembly.svg"`);
  html = html.replace(/href="\/brand\/logo-selected-dark\.svg"/g, `href="${prefix}brand/logo-selected-dark.svg"`);
  html = html.replace(/href="\/brand\/bbb-logo-official\.svg"/g, `href="${prefix}brand/bbb-logo-official.svg"`);
  html = html.replace(/href="\/visuals\/brake-assembly\.svg"/g, `href="${prefix}visuals/brake-assembly.svg"`);

  // Fix internal links
  html = html.replace(/href="\/used-car-parts"/g, `href="${prefix}used-car-parts.html"`);
  html = html.replace(/href="\/find-a-part\/"/g, `href="${prefix}find-a-part.html"`);
  html = html.replace(/href="\/find-a-part"/g, `href="${prefix}find-a-part.html"`);
  html = html.replace(/href="\/faq"/g, `href="${prefix}faq.html"`);
  html = html.replace(/href="\/blog"/g, `href="${prefix}blog.html"`);
  html = html.replace(/href="\/blog\//g, `href="${prefix}blog/`);
  html = html.replace(/href="\/#popular-parts"/g, `href="${prefix}index.html#popular-parts"`);
  html = html.replace(/href="\/#how-it-works"/g, `href="${prefix}index.html#how-it-works"`);
  html = html.replace(/href="\/#why-doorstep"/g, `href="${prefix}index.html#why-doorstep"`);
  html = html.replace(/href="\/"/g, `href="${prefix}index.html"`);

  // Blog post links
  html = html.replace(/href="blog\/([a-z0-9-]+)"/g, `href="${prefix}blog/$1.html"`);
  html = html.replace(/href="\.\.\/blog\/([a-z0-9-]+)"/g, `href="${prefix}blog/$1.html"`);

  // Inject custom stylesheet and main.js
  const extraHead = `
    <link rel="stylesheet" href="${prefix}assets/custom.css"/>
    <script defer src="${prefix}assets/main.js"></script>
  `;
  html = html.replace('</head>', `${extraHead}</head>`);

  // Ensure "All parts" is in the nav
  if (!html.includes('all-parts.html')) {
    html = html.replace(
      `<a href="${prefix}used-car-parts.html">Used car parts</a>`,
      `<a href="${prefix}used-car-parts.html">Used car parts</a><a href="${prefix}all-parts.html">All parts</a>`
    );
    html = html.replace(
      `<a href="${prefix}used-car-parts.html">Used car parts<svg viewBox="0 0 24 24" aria-hidden="true" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><path d="M4 12h15m-6-6 6 6-6 6"></path></svg></a>`,
      `<a href="${prefix}used-car-parts.html">Used car parts<svg viewBox="0 0 24 24" aria-hidden="true" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><path d="M4 12h15m-6-6 6 6-6 6"></path></svg></a><a href="${prefix}all-parts.html">All parts directory<svg viewBox="0 0 24 24" aria-hidden="true" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><path d="M4 12h15m-6-6 6 6-6 6"></path></svg></a>`
    );
  }

  return html;
}

// 1. Process index.html from step 7
console.log('Generating index.html...');
const homeRaw = fs.readFileSync(path.join(BRAIN_STEPS, '7/content.md'), 'utf-8');
fs.writeFileSync('d:/antigravity/v/index.html', cleanHtml(homeRaw, 0));

// 2. Process find-a-part.html from step 29
console.log('Generating find-a-part.html...');
const fmpRaw = fs.readFileSync(path.join(BRAIN_STEPS, '29/content.md'), 'utf-8');
let fmpHtml = cleanHtml(fmpRaw, 0);
// Ensure header and footer exist on find-a-part if not present in the body
if (!fmpHtml.includes('site-header')) {
  // Grab header and footer from index.html
  const homeDoc = fs.readFileSync('d:/antigravity/v/index.html', 'utf-8');
  const headerMatch = homeDoc.match(/<header class="site-header">[\s\S]*?<\/header>/);
  const footerMatch = homeDoc.match(/<footer class="site-footer">[\s\S]*?<\/footer>/);
  if (headerMatch && footerMatch) {
    fmpHtml = fmpHtml.replace('<body><!--$-->', `<body><!--$-->\n${headerMatch[0]}\n`);
    fmpHtml = fmpHtml.replace('</main>', `</main>\n${footerMatch[0]}`);
  }
}
fs.writeFileSync('d:/antigravity/v/find-a-part.html', fmpHtml);

// 3. Process faq.html from step 33
console.log('Generating faq.html...');
const faqRaw = fs.readFileSync(path.join(BRAIN_STEPS, '33/content.md'), 'utf-8');
fs.writeFileSync('d:/antigravity/v/faq.html', cleanHtml(faqRaw, 0));

// 4. Process used-car-parts.html from step 23
console.log('Generating used-car-parts.html...');
const ucpRaw = fs.readFileSync(path.join(BRAIN_STEPS, '23/content.md'), 'utf-8');
// Check if step 23 was markdown or html. Let's check:
if (ucpRaw.includes('<!DOCTYPE html>')) {
  fs.writeFileSync('d:/antigravity/v/used-car-parts.html', cleanHtml(ucpRaw, 0));
} else {
  console.log('Step 23 was markdown, will construct rich used-car-parts.html using site template');
}

// 5. Process blog.html from step 37
console.log('Checking blog.html...');
const blogRaw = fs.readFileSync(path.join(BRAIN_STEPS, '37/content.md'), 'utf-8');
if (blogRaw.includes('<!DOCTYPE html>')) {
  fs.writeFileSync('d:/antigravity/v/blog.html', cleanHtml(blogRaw, 0));
}

// 6. Process blog posts
const blog1Raw = fs.readFileSync(path.join(BRAIN_STEPS, '57/content.md'), 'utf-8');
if (blog1Raw.includes('<!DOCTYPE html>')) {
  fs.writeFileSync('d:/antigravity/v/blog/how-to-buy-a-used-engine.html', cleanHtml(blog1Raw, 1));
}

console.log('Base pages processed.');
