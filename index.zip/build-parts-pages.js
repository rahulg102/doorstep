const fs = require('fs');
const path = require('path');

// Read header and footer from index.html for perfect consistency
const indexHtml = fs.readFileSync('d:/antigravity/v/index.html', 'utf-8');
const headerMatch = indexHtml.match(/<header class="site-header">[\s\S]*?<\/header>/);
const footerMatch = indexHtml.match(/<footer class="site-footer">[\s\S]*?<\/footer>/);

const siteHeader = headerMatch ? headerMatch[0] : '';
const siteFooter = footerMatch ? footerMatch[0] : '';

// Function to adjust relative links based on depth (0 = root, 1 = /parts/)
function adjustNavLinks(markup, depth = 0) {
  const prefix = depth === 1 ? '../' : '';
  return markup
    .replace(/src="brand\//g, `src="${prefix}brand/`)
    .replace(/href="brand\//g, `href="${prefix}brand/`)
    .replace(/href="assets\//g, `href="${prefix}assets/`)
    .replace(/src="visuals\//g, `src="${prefix}visuals/`)
    .replace(/href="used-car-parts\.html"/g, `href="${prefix}used-car-parts.html"`)
    .replace(/href="find-a-part\.html"/g, `href="${prefix}find-a-part.html"`)
    .replace(/href="faq\.html"/g, `href="${prefix}faq.html"`)
    .replace(/href="blog\.html"/g, `href="${prefix}blog.html"`)
    .replace(/href="all-parts\.html"/g, `href="${prefix}all-parts.html"`)
    .replace(/href="index\.html"/g, `href="${prefix}index.html"`);
}

// 102 parts data
const AUTO_PARTS_CATALOG = [
  // 01 Engine & Engine Components (16)
  { id: "engine-complete", name: "Complete Engine", system: "Engine & Drivetrain", sysCode: "01", slug: "engine", difficulty: "Advanced", warranty: "90-Day to 1-Year", desc: "Complete long-block or full engine assembly including block, heads, internal rotating components, and available accessories." },
  { id: "engine-assembly", name: "Engine Assembly", system: "Engine & Drivetrain", sysCode: "01", slug: "engine", difficulty: "Advanced", warranty: "90-Day Standard", desc: "Core engine block and cylinder heads paired with timing components." },
  { id: "engine-block", name: "Engine Block", system: "Engine & Drivetrain", sysCode: "01", slug: "engine", difficulty: "Advanced", warranty: "90-Day Standard", desc: "Bare or short block assembly inspected for deck flatness and cylinder bore condition." },
  { id: "cylinder-head", name: "Cylinder Head", system: "Engine & Drivetrain", sysCode: "01", slug: "engine", difficulty: "Moderate", warranty: "90-Day Standard", desc: "Inspected valve guides, combustion chambers, and cam journals." },
  { id: "crankshaft", name: "Crankshaft", system: "Engine & Drivetrain", sysCode: "01", slug: "engine", difficulty: "Advanced", warranty: "90-Day Standard", desc: "Precision balanced crankshaft with micrometer-verified journal dimensions." },
  { id: "camshaft", name: "Camshaft", system: "Engine & Drivetrain", sysCode: "01", slug: "engine", difficulty: "Moderate", warranty: "90-Day Standard", desc: "OEM intake and exhaust camshafts with lobe condition inspected." },
  { id: "connecting-rod", name: "Connecting Rod", system: "Engine & Drivetrain", sysCode: "01", slug: "engine", difficulty: "Advanced", warranty: "90-Day Standard", desc: "OEM forged or cast connecting rods matched to engine specs." },
  { id: "intake-manifold", name: "Intake Manifold", system: "Engine & Drivetrain", sysCode: "01", slug: "engine", difficulty: "Moderate", warranty: "90-Day Standard", desc: "Plenum and runner assembly verified for cracks, runner valves, and mating surfaces." },
  { id: "exhaust-manifold", name: "Exhaust Manifold", system: "Engine & Drivetrain", sysCode: "01", slug: "engine", difficulty: "Moderate", warranty: "90-Day Standard", desc: "Cast or tubular exhaust manifold checked for thermal cracks and stud condition." },
  { id: "oil-pan", name: "Oil Pan", system: "Engine & Drivetrain", sysCode: "01", slug: "engine", difficulty: "Moderate", warranty: "90-Day Standard", desc: "Stamped steel or cast aluminum pan with intact drain threads and baffle." },
  { id: "valve-cover", name: "Valve Cover", system: "Engine & Drivetrain", sysCode: "01", slug: "engine", difficulty: "Easy", warranty: "90-Day Standard", desc: "OEM valve cover with breather ports and ignition coil mount bosses." },
  { id: "timing-cover", name: "Timing Cover", system: "Engine & Drivetrain", sysCode: "01", slug: "engine", difficulty: "Moderate", warranty: "90-Day Standard", desc: "Front engine cover protecting timing chain or belt assembly." },
  { id: "engine-mount", name: "Engine Mount", system: "Engine & Drivetrain", sysCode: "01", slug: "engine", difficulty: "Moderate", warranty: "90-Day Standard", desc: "Hydraulic or solid rubber vibration isolator bracket assembly." },
  { id: "turbocharger", name: "Turbocharger", system: "Engine & Drivetrain", sysCode: "01", slug: "engine", difficulty: "Advanced", warranty: "90-Day Standard", desc: "Exhaust-driven forced induction unit checked for shaft play, turbine fin integrity, and wastegate function." },
  { id: "supercharger", name: "Supercharger", system: "Engine & Drivetrain", sysCode: "01", slug: "engine", difficulty: "Advanced", warranty: "90-Day Standard", desc: "Belt-driven positive displacement or centrifugal supercharger assembly." },
  { id: "harmonic-balancer", name: "Harmonic Balancer", system: "Engine & Drivetrain", sysCode: "01", slug: "engine", difficulty: "Moderate", warranty: "90-Day Standard", desc: "Crankshaft damper pulley with bonded elastomeric ring inspected." },

  // 02 Transmission & Drivetrain (15)
  { id: "automatic-transmission", name: "Automatic Transmission", system: "Transmission & Powertrain", sysCode: "02", slug: "transmission", difficulty: "Advanced", warranty: "90-Day to 1-Year", desc: "Complete automatic transmission unit including case, valve body, and converter match verified by tag code." },
  { id: "manual-transmission", name: "Manual Transmission", system: "Transmission & Powertrain", sysCode: "02", slug: "transmission", difficulty: "Advanced", warranty: "90-Day Standard", desc: "Manual gearbox with smooth synchronizer engagement and input shaft integrity." },
  { id: "transmission-assembly", name: "Transmission Assembly", system: "Transmission & Powertrain", sysCode: "02", slug: "transmission", difficulty: "Advanced", warranty: "90-Day to 1-Year", desc: "Tested transmission assembly matched to vehicle VIN, drivetrain, and gear ratio." },
  { id: "transfer-case", name: "Transfer Case", system: "Transmission & Powertrain", sysCode: "02", slug: "transfer-case", difficulty: "Advanced", warranty: "90-Day Standard", desc: "4WD/AWD transfer unit checked for chain tension, shift motor operation, and fluid condition." },
  { id: "differential", name: "Differential", system: "Transmission & Powertrain", sysCode: "02", slug: "differential", difficulty: "Advanced", warranty: "90-Day Standard", desc: "Front or rear differential carrier assembly with ring and pinion backlash inspected." },
  { id: "front-axle-assembly", name: "Front Axle Assembly", system: "Transmission & Powertrain", sysCode: "02", slug: "differential", difficulty: "Advanced", warranty: "90-Day Standard", desc: "Complete front axle housing, carrier, and axle tubes for 4x4 and AWD vehicles." },
  { id: "rear-axle-assembly", name: "Rear Axle Assembly", system: "Transmission & Powertrain", sysCode: "02", slug: "differential", difficulty: "Advanced", warranty: "90-Day Standard", desc: "Solid or independent rear axle carrier assembly with gear ratio match confirmed." },
  { id: "axle-shaft", name: "Axle Shaft", system: "Transmission & Powertrain", sysCode: "02", slug: "differential", difficulty: "Moderate", warranty: "90-Day Standard", desc: "Hardened steel drive axle shaft with splines and wheel flange verified true." },
  { id: "cv-axle", name: "CV Axle", system: "Transmission & Powertrain", sysCode: "02", slug: "transmission", difficulty: "Moderate", warranty: "90-Day Standard", desc: "Constant velocity axle shaft with intact boots and tight joint tolerances." },
  { id: "driveshaft", name: "Driveshaft", system: "Transmission & Powertrain", sysCode: "02", slug: "transmission", difficulty: "Moderate", warranty: "90-Day Standard", desc: "Balanced propeller shaft assembly with carrier bearings and U-joints." },
  { id: "torque-converter", name: "Torque Converter", system: "Transmission & Powertrain", sysCode: "02", slug: "transmission", difficulty: "Moderate", warranty: "90-Day Standard", desc: "Hydraulic fluid coupling matched to engine torque curve and transmission stator." },
  { id: "flywheel", name: "Flywheel", system: "Transmission & Powertrain", sysCode: "02", slug: "transmission", difficulty: "Moderate", warranty: "90-Day Standard", desc: "Manual transmission friction disc surface and ring gear teeth inspected." },
  { id: "flexplate", name: "Flexplate", system: "Transmission & Powertrain", sysCode: "02", slug: "transmission", difficulty: "Moderate", warranty: "90-Day Standard", desc: "Automatic transmission drive plate checked for cracking and starter ring gear wear." },
  { id: "clutch-assembly", name: "Clutch Assembly", system: "Transmission & Powertrain", sysCode: "02", slug: "transmission", difficulty: "Moderate", warranty: "90-Day Standard", desc: "Pressure plate, clutch disc, and release fork mechanism." },
  { id: "transmission-control-module", name: "Transmission Control Module", system: "Transmission & Powertrain", sysCode: "02", slug: "transmission", difficulty: "Moderate", warranty: "90-Day Standard", desc: "TCM unit programmed for transmission solenoid sequencing and shift maps." },

  // 03 Body & Exterior (17)
  { id: "front-bumper", name: "Front Bumper", system: "Body & Exterior", sysCode: "03", slug: "front-bumper", difficulty: "Moderate", warranty: "Fitment Guarantee", desc: "Front bumper face bar or complete assembly matched to vehicle trim and fog lamp cutouts." },
  { id: "rear-bumper", name: "Rear Bumper", system: "Body & Exterior", sysCode: "03", slug: "front-bumper", difficulty: "Moderate", warranty: "Fitment Guarantee", desc: "Rear step bumper or bumper assembly with backup sensor provisions." },
  { id: "bumper-cover", name: "Bumper Cover", system: "Body & Exterior", sysCode: "03", slug: "front-bumper", difficulty: "Moderate", warranty: "Fitment Guarantee", desc: "Fascia shell inspected for mounting tab integrity and grille alignment." },
  { id: "bumper-assembly", name: "Bumper Assembly", system: "Body & Exterior", sysCode: "03", slug: "front-bumper", difficulty: "Moderate", warranty: "Fitment Guarantee", desc: "Complete unit including reinforcement beam, impact absorbers, and cover." },
  { id: "fender", name: "Fender", system: "Body & Exterior", sysCode: "03", slug: "front-bumper", difficulty: "Moderate", warranty: "Fitment Guarantee", desc: "Left or right front quarter sheet metal panel matched to wheel opening and lamp pockets." },
  { id: "hood", name: "Hood", system: "Body & Exterior", sysCode: "03", slug: "front-bumper", difficulty: "Moderate", warranty: "Fitment Guarantee", desc: "Engine hood panel checked for hinge straightness, latch loop, and skin seams." },
  { id: "front-door", name: "Front Door", system: "Body & Exterior", sysCode: "03", slug: "front-bumper", difficulty: "Moderate", warranty: "Fitment Guarantee", desc: "Driver or passenger front door shell with hinge pins and lock mechanisms." },
  { id: "rear-door", name: "Rear Door", system: "Body & Exterior", sysCode: "03", slug: "front-bumper", difficulty: "Moderate", warranty: "Fitment Guarantee", desc: "Rear passenger door shell matched to sedan, SUV, or crew cab body configurations." },
  { id: "trunk-lid", name: "Trunk Lid", system: "Body & Exterior", sysCode: "03", slug: "front-bumper", difficulty: "Moderate", warranty: "Fitment Guarantee", desc: "Decklid panel with spoiler options, camera holes, and latch alignment." },
  { id: "tailgate", name: "Tailgate", system: "Body & Exterior", sysCode: "03", slug: "front-bumper", difficulty: "Moderate", warranty: "Fitment Guarantee", desc: "Pickup truck tailgate with torsion bar, latch handle, and reverse camera provision." },
  { id: "liftgate", name: "Liftgate", system: "Body & Exterior", sysCode: "03", slug: "front-bumper", difficulty: "Moderate", warranty: "Fitment Guarantee", desc: "SUV / hatchback rear door with power actuator and wiper motor provisions." },
  { id: "grille", name: "Grille", system: "Body & Exterior", sysCode: "03", slug: "front-bumper", difficulty: "Easy", warranty: "Fitment Guarantee", desc: "Front radiator grille with emblem mount and active shutter provisions." },
  { id: "side-mirror", name: "Side Mirror", system: "Body & Exterior", sysCode: "03", slug: "front-bumper", difficulty: "Easy", warranty: "90-Day Standard", desc: "Power, heated, blind-spot detection, or folding side view mirror assembly." },
  { id: "radiator-support", name: "Radiator Support", system: "Body & Exterior", sysCode: "03", slug: "front-bumper", difficulty: "Advanced", warranty: "Fitment Guarantee", desc: "Core support frame holding cooling module, headlamps, and latch." },
  { id: "quarter-panel", name: "Quarter Panel", system: "Body & Exterior", sysCode: "03", slug: "front-bumper", difficulty: "Advanced", warranty: "Fitment Guarantee", desc: "Rear body quarter panel section cut to repair shop specifications." },
  { id: "window-regulator", name: "Window Regulator", system: "Body & Exterior", sysCode: "03", slug: "front-bumper", difficulty: "Moderate", warranty: "90-Day Standard", desc: "Scissor or cable door glass lifting track mechanism." },
  { id: "door-handle", name: "Door Handle", system: "Body & Exterior", sysCode: "03", slug: "front-bumper", difficulty: "Easy", warranty: "90-Day Standard", desc: "Interior or exterior door handle with keyless sensor or lock rod clip." },

  // 04 Electrical Components (12)
  { id: "alternator", name: "Alternator", system: "Electrical & Lighting", sysCode: "04", slug: "alternator", difficulty: "Moderate", warranty: "90-Day to 1-Year", desc: "High-output charging generator bench-tested for diode ripple and voltage regulation." },
  { id: "starter-motor", name: "Starter Motor", system: "Electrical & Lighting", sysCode: "04", slug: "alternator", difficulty: "Moderate", warranty: "90-Day to 1-Year", desc: "High-torque starter motor tested for solenoid throw and armature current draw." },
  { id: "engine-control-module", name: "Engine Control Module", system: "Electrical & Lighting", sysCode: "04", slug: "alternator", difficulty: "Moderate", warranty: "90-Day Standard", desc: "OEM ECU / ECM matched by part number and hardware revision." },
  { id: "powertrain-control-module", name: "Powertrain Control Module", system: "Electrical & Lighting", sysCode: "04", slug: "alternator", difficulty: "Moderate", warranty: "90-Day Standard", desc: "Integrated engine and transmission computer unit." },
  { id: "wiring-harness", name: "Wiring Harness", system: "Electrical & Lighting", sysCode: "04", slug: "alternator", difficulty: "Advanced", warranty: "90-Day Standard", desc: "Engine bay, dash, or chassis harness with uncut connectors." },
  { id: "fuse-box", name: "Fuse Box", system: "Electrical & Lighting", sysCode: "04", slug: "alternator", difficulty: "Moderate", warranty: "90-Day Standard", desc: "Totally integrated power module (TIPM) or underhood junction box." },
  { id: "ignition-coil", name: "Ignition Coil", system: "Electrical & Lighting", sysCode: "04", slug: "alternator", difficulty: "Easy", warranty: "90-Day Standard", desc: "Coil-on-plug or multi-pack ignition transformer." },
  { id: "instrument-cluster", name: "Instrument Cluster", system: "Electrical & Lighting", sysCode: "04", slug: "alternator", difficulty: "Moderate", warranty: "90-Day Standard", desc: "Digital or analog gauge cluster matched to vehicle options." },
  { id: "window-switch", name: "Window Switch", system: "Electrical & Lighting", sysCode: "04", slug: "alternator", difficulty: "Easy", warranty: "90-Day Standard", desc: "Master driver door window and lock switch cluster." },
  { id: "power-window-motor", name: "Power Window Motor", system: "Electrical & Lighting", sysCode: "04", slug: "alternator", difficulty: "Moderate", warranty: "90-Day Standard", desc: "Reversible DC electric motor driving window lift track." },
  { id: "body-control-module", name: "Body Control Module", system: "Electrical & Lighting", sysCode: "04", slug: "alternator", difficulty: "Moderate", warranty: "90-Day Standard", desc: "BCM controlling lighting, door locks, alarm, and comfort convenience." },
  { id: "electronic-sensors", name: "Various Electronic Sensors", system: "Electrical & Lighting", sysCode: "04", slug: "alternator", difficulty: "Easy", warranty: "90-Day Standard", desc: "Mass air flow, crankshaft position, camshaft position, and manifold sensors." },

  // 05 Headlights & Lighting (7)
  { id: "headlight-assembly", name: "Headlight Assembly", system: "Electrical & Lighting", sysCode: "05", slug: "headlight", difficulty: "Moderate", warranty: "Fitment Guarantee", desc: "Halogen, Xenon HID, or full LED headlamp assembly with intact housing tabs and clear lens." },
  { id: "tail-light-assembly", name: "Tail Light Assembly", system: "Electrical & Lighting", sysCode: "05", slug: "headlight", difficulty: "Easy", warranty: "Fitment Guarantee", desc: "Rear quarter or trunk-mounted tail lamp housing with intact wiring." },
  { id: "fog-light", name: "Fog Light", system: "Electrical & Lighting", sysCode: "05", slug: "headlight", difficulty: "Easy", warranty: "Fitment Guarantee", desc: "Lower bumper mounted auxiliary driving or fog lamp unit." },
  { id: "turn-signal-light", name: "Turn Signal Light", system: "Electrical & Lighting", sysCode: "05", slug: "headlight", difficulty: "Easy", warranty: "Fitment Guarantee", desc: "Amber corner or bumper turn indicator light assembly." },
  { id: "daytime-running-light", name: "Daytime Running Light", system: "Electrical & Lighting", sysCode: "05", slug: "headlight", difficulty: "Easy", warranty: "Fitment Guarantee", desc: "Dedicated DRL light bar or bumper bezel assembly." },
  { id: "third-brake-light", name: "Third Brake Light", system: "Electrical & Lighting", sysCode: "05", slug: "headlight", difficulty: "Easy", warranty: "Fitment Guarantee", desc: "Center high-mounted stop light (CHMSL) with LED array tested." },
  { id: "headlight-control-module", name: "Headlight Control Module", system: "Electrical & Lighting", sysCode: "05", slug: "headlight", difficulty: "Easy", warranty: "90-Day Standard", desc: "Xenon ballast or adaptive LED curve lighting driver module." },

  // 06 Cooling & HVAC (10)
  { id: "radiator", name: "Radiator", system: "Cooling & HVAC", sysCode: "06", slug: "ac-compressor", difficulty: "Moderate", warranty: "90-Day Standard", desc: "Engine coolant heat exchanger pressure-tested for core and tank seal integrity." },
  { id: "radiator-fan", name: "Radiator Fan", system: "Cooling & HVAC", sysCode: "06", slug: "ac-compressor", difficulty: "Moderate", warranty: "90-Day Standard", desc: "Electric cooling fan motor and blade assembly." },
  { id: "cooling-fan-assembly", name: "Cooling Fan Assembly", system: "Cooling & HVAC", sysCode: "06", slug: "ac-compressor", difficulty: "Moderate", warranty: "90-Day Standard", desc: "Dual fan shroud assembly with integrated control module." },
  { id: "ac-compressor", name: "AC Compressor", system: "Cooling & HVAC", sysCode: "06", slug: "ac-compressor", difficulty: "Advanced", warranty: "90-Day to 1-Year", desc: "Air conditioning pump tested for magnetic clutch engagement, shaft turn, and suction/discharge pressure." },
  { id: "ac-condenser", name: "AC Condenser", system: "Cooling & HVAC", sysCode: "06", slug: "ac-compressor", difficulty: "Moderate", warranty: "90-Day Standard", desc: "High-pressure refrigerant condenser mounted forward of radiator." },
  { id: "heater-core", name: "Heater Core", system: "Cooling & HVAC", sysCode: "06", slug: "ac-compressor", difficulty: "Advanced", warranty: "90-Day Standard", desc: "Cabin heat exchanger checked for fin blockage and tube corrosion." },
  { id: "blower-motor", name: "Blower Motor", system: "Cooling & HVAC", sysCode: "06", slug: "ac-compressor", difficulty: "Easy", warranty: "90-Day Standard", desc: "HVAC cabin ventilation fan motor with squirrel cage impeller." },
  { id: "water-pump", name: "Water Pump", system: "Cooling & HVAC", sysCode: "06", slug: "ac-compressor", difficulty: "Moderate", warranty: "90-Day Standard", desc: "Mechanical or auxiliary electric engine coolant circulation pump." },
  { id: "thermostat-housing", name: "Thermostat Housing", system: "Cooling & HVAC", sysCode: "06", slug: "ac-compressor", difficulty: "Easy", warranty: "90-Day Standard", desc: "Coolant outlet neck or electronic thermostat housing assembly." },
  { id: "intercooler", name: "Intercooler", system: "Cooling & HVAC", sysCode: "06", slug: "ac-compressor", difficulty: "Moderate", warranty: "90-Day Standard", desc: "Turbo/supercharger charge air cooler inspected for boost leak." },

  // 07 Steering & Suspension (10)
  { id: "steering-rack", name: "Steering Rack", system: "Steering & Suspension", sysCode: "07", slug: "steering-rack", difficulty: "Advanced", warranty: "90-Day to 1-Year", desc: "Hydraulic or electric power steering rack and pinion with tie rod threads inspected." },
  { id: "steering-column", name: "Steering Column", system: "Steering & Suspension", sysCode: "07", slug: "steering-rack", difficulty: "Advanced", warranty: "90-Day Standard", desc: "Tilt/telescoping steering shaft with ignition housing and intermediate shaft." },
  { id: "power-steering-pump", name: "Power Steering Pump", system: "Steering & Suspension", sysCode: "07", slug: "steering-rack", difficulty: "Moderate", warranty: "90-Day Standard", desc: "Belt-driven hydraulic pump or electric-hydraulic power steering unit." },
  { id: "control-arm", name: "Control Arm", system: "Steering & Suspension", sysCode: "07", slug: "steering-rack", difficulty: "Moderate", warranty: "90-Day Standard", desc: "Upper or lower A-arm with ball joint taper and bushings inspected." },
  { id: "steering-knuckle", name: "Steering Knuckle", system: "Steering & Suspension", sysCode: "07", slug: "steering-rack", difficulty: "Moderate", warranty: "90-Day Standard", desc: "Cast wheel spindle upright with brake caliper ears and strut mounts." },
  { id: "strut-assembly", name: "Strut Assembly", system: "Steering & Suspension", sysCode: "07", slug: "steering-rack", difficulty: "Moderate", warranty: "90-Day Standard", desc: "MacPherson strut damper with coil spring and top mount bearing." },
  { id: "shock-absorber", name: "Shock Absorber", system: "Steering & Suspension", sysCode: "07", slug: "steering-rack", difficulty: "Moderate", warranty: "90-Day Standard", desc: "Monotube or twin-tube suspension damper inspected for fluid leakage." },
  { id: "suspension-subframe", name: "Suspension Subframe", system: "Steering & Suspension", sysCode: "07", slug: "steering-rack", difficulty: "Advanced", warranty: "Fitment Guarantee", desc: "Front engine cradle or rear subframe crossmember checked true on frame jig." },
  { id: "sway-bar", name: "Sway Bar", system: "Steering & Suspension", sysCode: "07", slug: "steering-rack", difficulty: "Moderate", warranty: "90-Day Standard", desc: "Anti-roll stabilizer bar with link mounts and bushing collars." },
  { id: "tie-rod-assembly", name: "Tie Rod Assembly", system: "Steering & Suspension", sysCode: "07", slug: "steering-rack", difficulty: "Moderate", warranty: "90-Day Standard", desc: "Inner and outer tie rod ends with adjustment sleeve." },

  // 08 Braking & Wheel Components (7)
  { id: "brake-caliper", name: "Brake Caliper", system: "Braking Systems", sysCode: "08", slug: "brake-caliper", difficulty: "Moderate", warranty: "90-Day Standard", desc: "Front or rear hydraulic caliper with slide pins, piston seal, and bracket." },
  { id: "brake-booster", name: "Brake Booster", system: "Braking Systems", sysCode: "08", slug: "brake-caliper", difficulty: "Moderate", warranty: "90-Day Standard", desc: "Vacuum diaphragm or hydraulic brake power booster unit." },
  { id: "master-cylinder", name: "Master Cylinder", system: "Braking Systems", sysCode: "08", slug: "brake-caliper", difficulty: "Moderate", warranty: "90-Day Standard", desc: "Dual-circuit brake fluid master reservoir and piston cylinder." },
  { id: "abs-control-module", name: "ABS Control Module", system: "Braking Systems", sysCode: "08", slug: "brake-caliper", difficulty: "Moderate", warranty: "90-Day to 1-Year", desc: "Anti-lock brake hydraulic control unit and electronic solenoid module." },
  { id: "wheel-hub", name: "Wheel Hub", system: "Braking Systems", sysCode: "08", slug: "brake-caliper", difficulty: "Moderate", warranty: "90-Day Standard", desc: "Hub assembly with wheel studs and integrated speed sensor ring." },
  { id: "wheel-bearing", name: "Wheel Bearing", system: "Braking Systems", sysCode: "08", slug: "brake-caliper", difficulty: "Moderate", warranty: "90-Day Standard", desc: "Press-in or bolt-on unit bearing tested for zero radial runout." },
  { id: "wheel-rim", name: "Wheel Rim", system: "Braking Systems", sysCode: "08", slug: "brake-caliper", difficulty: "Easy", warranty: "Fitment Guarantee", desc: "OEM alloy or steel wheel checked for roundness, crack absence, and lug bore fit." },

  // 09 Interior Components (8)
  { id: "front-seat", name: "Front Seat", system: "Interior Components", sysCode: "09", slug: "part-detail", difficulty: "Moderate", warranty: "Fitment Guarantee", desc: "Driver or passenger bucket seat with power tracks and airbag modules." },
  { id: "rear-seat", name: "Rear Seat", system: "Interior Components", sysCode: "09", slug: "part-detail", difficulty: "Moderate", warranty: "Fitment Guarantee", desc: "Bench or split-folding 60/40 rear seat matched to upholstery color code." },
  { id: "dashboard", name: "Dashboard", system: "Interior Components", sysCode: "09", slug: "part-detail", difficulty: "Advanced", warranty: "Fitment Guarantee", desc: "Main instrument panel pad and frame assembly." },
  { id: "center-console", name: "Center Console", system: "Interior Components", sysCode: "09", slug: "part-detail", difficulty: "Easy", warranty: "Fitment Guarantee", desc: "Floor console with armrest lid, cupholders, and shifter bezel." },
  { id: "door-panel", name: "Door Panel", system: "Interior Components", sysCode: "09", slug: "part-detail", difficulty: "Easy", warranty: "Fitment Guarantee", desc: "Interior door card upholstery matched to cabin trim code." },
  { id: "infotainment-unit", name: "Infotainment Unit", system: "Interior Components", sysCode: "09", slug: "part-detail", difficulty: "Moderate", warranty: "90-Day Standard", desc: "Touchscreen radio, navigation, and audio receiver display." },
  { id: "climate-control-panel", name: "Climate Control Panel", system: "Interior Components", sysCode: "09", slug: "part-detail", difficulty: "Easy", warranty: "90-Day Standard", desc: "Automatic or manual AC heater control faceplate switch." },
  { id: "interior-trim-components", name: "Interior Trim Components", system: "Interior Components", sysCode: "09", slug: "part-detail", difficulty: "Easy", warranty: "Fitment Guarantee", desc: "Pillar trim, sill plates, dash vents, and console garnish." }
];

// Generate all-parts.html
console.log('Generating all-parts.html...');
const allPartsCards = AUTO_PARTS_CATALOG.map((p, idx) => {
  const code = (idx + 1).toString().padStart(3, '0');
  const partUrl = p.slug !== 'part-detail' ? `parts/${p.slug}.html` : `parts/part-detail.html?part=${encodeURIComponent(p.name)}`;
  return `
    <article class="part-card-pro" data-system="${p.system}">
      <div>
        <div class="part-card-header">
          <span class="part-system-badge">${p.system}</span>
          <span class="part-number-code">PART #${code}</span>
        </div>
        <h3 class="part-card-title">${p.name}</h3>
        <p class="part-card-desc">${p.desc}</p>
        <div class="part-card-meta">
          <div class="part-card-meta-item">
            <span>Install Scope</span>
            <strong>${p.difficulty}</strong>
          </div>
          <div class="part-card-meta-item">
            <span>Warranty Tier</span>
            <strong>${p.warranty}</strong>
          </div>
        </div>
      </div>
      <div class="part-card-actions">
        <a href="${partUrl}" class="button button-text-light" style="background:#eef4f3; color:#153b43; border:1px solid #c9d6d4;">View Specs</a>
        <a href="find-a-part.html?part=${encodeURIComponent(p.name)}" class="button button-blue">Request Quote</a>
      </div>
    </article>
  `;
}).join('\n');

const allPartsHtml = `<!DOCTYPE html>
<html lang="en-US">
<head>
  <meta charSet="utf-8"/>
  <meta name="viewport" content="width=device-width, initial-scale=1"/>
  <title>All Auto Parts Directory | Doorstep Auto Parts</title>
  <meta name="description" content="Explore all 102 automotive replacement parts for cars, trucks, and SUVs. Request engines, transmissions, electrical, cooling, and body parts across the USA."/>
  <link rel="icon" href="brand/favicon-option-b.svg"/>
  <link rel="stylesheet" href="assets/styles.css"/>
  <link rel="stylesheet" href="assets/custom.css"/>
  <script defer src="assets/main.js"></script>
</head>
<body>
  ${siteHeader}
  <main id="all-parts-page">
    <section class="hero" style="padding: 4.5rem 0 3.5rem;">
      <div class="shell">
        <p class="hero-kicker"><span></span> Complete Parts Directory / 001</p>
        <h1 id="hero-title" style="font-size: clamp(2.5rem, 5vw, 4.2rem); line-height: 1.05; margin-bottom: 1rem;">
          ALL AUTO PARTS.<br/><em>COMPREHENSIVE CATALOG.</em>
        </h1>
        <p class="hero-lede" style="max-width: 680px;">
          Browse all 102 commonly requested replacement components across 9 primary automotive systems. Every part is verified by our sourcing specialists for fitment, donor condition, and delivered cost before purchase.
        </p>
        <div class="hero-actions" style="margin-top: 1.75rem;">
          <a class="button button-blue" href="find-a-part.html">Request Any Part <svg viewBox="0 0 24 24" aria-hidden="true" fill="none" stroke="currentColor" stroke-width="1.5"><path d="M4 12h15m-6-6 6 6-6 6"></path></svg></a>
          <a class="button button-text-light" href="tel:+18888790515"><svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="1.5"><path d="M7 3h3l1.2 4.1-2 1.7a15.5 15.5 0 0 0 6 6l1.7-2L21 14v3a4 4 0 0 1-4 4A14 14 0 0 1 3 7a4 4 0 0 1 4-4Z"></path></svg> Speak with Specialist (888) 879-0515</a>
        </div>
      </div>
    </section>

    <section class="section-pad" style="background:#f4f5f1; min-height: 60vh;">
      <div class="shell">
        <div class="section-intro" style="margin-bottom: 2rem;">
          <div>
            <p class="section-index">SEARCH &amp; FILTER / 002</p>
            <h2>102 Replacement Parts</h2>
          </div>
          <p>Filter by automotive system or search by name. Each part includes fitment inspection criteria, warranty guidelines, and direct sourcing availability.</p>
        </div>

        <div class="catalog-search-bar">
          <svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="#52696f" stroke-width="2"><circle cx="11" cy="11" r="8"></circle><line x1="21" y1="21" x2="16.65" y2="16.65"></line></svg>
          <input type="search" id="catalog-search" placeholder="Search by part name (e.g. Engine, Bumper, Caliper, Alternator)..." aria-label="Search all parts"/>
          <span class="filter-count" id="catalog-match-count">102 Parts Available</span>
        </div>

        <div class="makes-quick-grid" style="margin-bottom: 2rem;">
          <button type="button" class="make-pill-btn active" onclick="filterCatalogSystem('All')">All Systems (102)</button>
          <button type="button" class="make-pill-btn" onclick="filterCatalogSystem('Engine & Drivetrain')">Engine (16)</button>
          <button type="button" class="make-pill-btn" onclick="filterCatalogSystem('Transmission & Powertrain')">Transmission (15)</button>
          <button type="button" class="make-pill-btn" onclick="filterCatalogSystem('Body & Exterior')">Body &amp; Exterior (17)</button>
          <button type="button" class="make-pill-btn" onclick="filterCatalogSystem('Electrical & Lighting')">Electrical &amp; Lighting (19)</button>
          <button type="button" class="make-pill-btn" onclick="filterCatalogSystem('Cooling & HVAC')">Cooling &amp; HVAC (10)</button>
          <button type="button" class="make-pill-btn" onclick="filterCatalogSystem('Steering & Suspension')">Steering &amp; Suspension (10)</button>
          <button type="button" class="make-pill-btn" onclick="filterCatalogSystem('Braking Systems')">Braking (7)</button>
          <button type="button" class="make-pill-btn" onclick="filterCatalogSystem('Interior Components')">Interior (8)</button>
        </div>

        <div class="parts-catalog-grid" id="all-parts-container">
          ${allPartsCards}
        </div>
      </div>
    </section>

    <!-- Closing Banner -->
    <section class="closing-section">
      <div class="shell closing-grid">
        <div>
          <p class="section-index">EXPERT SOURCING / 003</p>
          <h2>Don't see your specific part?</h2>
          <p>Our network connects to thousands of certified automotive recyclers across North America. Tell us what you drive and we'll check inventory nationwide.</p>
        </div>
        <div class="closing-actions">
          <a class="button button-blue" href="find-a-part.html">Request Custom Part <svg viewBox="0 0 24 24" aria-hidden="true" fill="none" stroke="currentColor" stroke-width="1.5"><path d="M4 12h15m-6-6 6 6-6 6"></path></svg></a>
          <a class="button button-outline-light" href="tel:+18888790515"><svg viewBox="0 0 24 24" aria-hidden="true" fill="none" stroke="currentColor" stroke-width="1.5"><path d="M7 3h3l1.2 4.1-2 1.7a15.5 15.5 0 0 0 6 6l1.7-2L21 14v3a4 4 0 0 1-4 4A14 14 0 0 1 3 7a4 4 0 0 1 4-4Z"></path></svg> Call (888) 879-0515</a>
        </div>
      </div>
    </section>
  </main>
  ${siteFooter}

  <script>
    function filterCatalogSystem(sys) {
      document.querySelectorAll('.make-pill-btn').forEach(b => b.classList.remove('active'));
      event.target.classList.add('active');
      const cards = document.querySelectorAll('.part-card-pro');
      let count = 0;
      cards.forEach(card => {
        if (sys === 'All' || card.dataset.system.includes(sys)) {
          card.style.display = '';
          count++;
        } else {
          card.style.display = 'none';
        }
      });
      document.getElementById('catalog-match-count').textContent = count + ' Parts Available';
    }
  </script>
</body>
</html>`;

fs.writeFileSync('d:/antigravity/v/all-parts.html', allPartsHtml);
console.log('-> Saved d:/antigravity/v/all-parts.html');

// Helper to create a dedicated Part Detail Page
function createPartDetailPage({ title, subtitle, system, sysCode, partSlug, desc, specs, checklist, faqs, svgArt }) {
  const adjustedHeader = adjustNavLinks(siteHeader, 1);
  const adjustedFooter = adjustNavLinks(siteFooter, 1);

  const specRows = Object.entries(specs).map(([k, v]) => `
    <tr>
      <th>${k}</th>
      <td>${v}</td>
    </tr>
  `).join('\n');

  const checkItems = checklist.map(item => `
    <li class="checklist-item">
      <svg class="checklist-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><polyline points="20 6 9 17 4 12"></polyline></svg>
      <span>${item}</span>
    </li>
  `).join('\n');

  const faqItems = faqs.map((f, i) => `
    <details data-faq-item="true" style="margin-bottom:0.75rem; background:#ffffff; border:1px solid #d4dfdd; border-radius:0.5rem; padding:1rem 1.25rem;">
      <summary style="font-weight:600; color:#153b43; cursor:pointer; font-size:1.05rem; display:flex; justify-content:space-between; align-items:center;">
        <span>${f.q}</span>
        <svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2"><path d="M12 4v16M4 12h16"></path></svg>
      </summary>
      <p style="margin-top:0.85rem; color:#52696f; line-height:1.6; font-size:0.95rem;">${f.a}</p>
    </details>
  `).join('\n');

  return `<!DOCTYPE html>
<html lang="en-US">
<head>
  <meta charSet="utf-8"/>
  <meta name="viewport" content="width=device-width, initial-scale=1"/>
  <title>${title} Online Across the USA | Doorstep Auto Parts</title>
  <meta name="description" content="Request OEM replacement ${title} with verified compatibility, testing documentation, and nationwide shipping. Call (888) 879-0515."/>
  <link rel="icon" href="../brand/favicon-option-b.svg"/>
  <link rel="stylesheet" href="../assets/styles.css"/>
  <link rel="stylesheet" href="../assets/custom.css"/>
  <script defer src="../assets/main.js"></script>
</head>
<body>
  ${adjustedHeader}
  <main class="part-page-detail">
    <!-- Hero Section -->
    <section class="part-detail-hero">
      <div class="shell part-detail-grid">
        <div>
          <div style="display:flex; align-items:center; gap:0.75rem; margin-bottom:1rem;">
            <a href="../all-parts.html" style="color:#91b8ff; text-decoration:none; font-size:0.85rem; text-transform:uppercase; letter-spacing:0.05em; font-weight:600;">← All Parts</a>
            <span style="color:rgba(255,255,255,0.3);">/</span>
            <span style="color:#f4f5f1; font-size:0.85rem; text-transform:uppercase; letter-spacing:0.05em; font-weight:600;">${system}</span>
          </div>
          <h1 style="font-size: clamp(2.4rem, 4.5vw, 3.8rem); line-height: 1.1; margin-bottom: 1rem; color:#f4f5f1;">
            ${title.toUpperCase()}<br/><em style="color:#91b8ff; font-style:normal;">OEM &amp; REPLACEMENT.</em>
          </h1>
          <p style="font-size: 1.1rem; color: #d4e0e2; line-height: 1.6; margin-bottom: 1.75rem; max-width: 600px;">
            ${desc}
          </p>
          <div style="display:flex; gap:1rem; flex-wrap:wrap;">
            <a href="../find-a-part.html?part=${encodeURIComponent(title)}" class="button button-blue">Request ${title} Availability <svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="2"><path d="M4 12h15m-6-6 6 6-6 6"></path></svg></a>
            <a href="tel:+18888790515" class="button button-text-light"><svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="1.5"><path d="M7 3h3l1.2 4.1-2 1.7a15.5 15.5 0 0 0 6 6l1.7-2L21 14v3a4 4 0 0 1-4 4A14 14 0 0 1 3 7a4 4 0 0 1 4-4Z"></path></svg> (888) 879-0515</a>
          </div>
        </div>

        <div style="display:flex; justify-content:center; align-items:center;">
          ${svgArt}
        </div>
      </div>
    </section>

    <!-- Technical Specs & Fitment Grid -->
    <section class="section-pad" style="background:#f4f5f1;">
      <div class="shell" style="display:grid; grid-template-columns: 1.1fr 0.9fr; gap:3rem; align-items:start;">
        <div>
          <div class="section-intro" style="margin-bottom:1.5rem;">
            <div>
              <p class="section-index">TECHNICAL SPECIFICATION / 001</p>
              <h2>Fitment &amp; Sourcing Standards</h2>
            </div>
          </div>
          <p style="color:#52696f; line-height:1.6; margin-bottom:1.5rem;">
            Before purchasing any replacement ${title.toLowerCase()}, our specialist team verifies manufacturing tolerances, donor vehicle history, and exact vehicle calibration.
          </p>

          <table class="part-spec-table">
            <tbody>
              ${specRows}
            </tbody>
          </table>

          <div class="checklist-card">
            <h3 style="font-size:1.25rem; color:#153b43; font-weight:700; margin-bottom:0.5rem;">Pre-Order Fitment Checklist</h3>
            <p style="font-size:0.875rem; color:#52696f;">Have these details ready when requesting your quote:</p>
            <ul class="checklist-list">
              ${checkItems}
            </ul>
          </div>
        </div>

        <!-- Inline Request Form -->
        <div style="background:#ffffff; border:1px solid #c9d6d4; border-radius:1rem; padding:2rem; box-shadow:0 12px 30px rgba(21,59,67,0.06); position:sticky; top:100px;">
          <div style="margin-bottom:1.25rem;">
            <p style="font-family:var(--font-display); font-size:0.8rem; font-weight:700; color:#225bd6; letter-spacing:0.05em; text-transform:uppercase;">Direct Part Request / 002</p>
            <h3 style="font-size:1.6rem; color:#153b43; font-weight:700;">Find Your ${title}</h3>
            <p style="font-size:0.875rem; color:#52696f;">Enter your vehicle details to check nationwide recycler inventory.</p>
          </div>

          <form noValidate="" aria-busy="false">
            <input type="hidden" name="part" value="${title}"/>
            <div style="display:grid; grid-template-columns: 1fr 1fr; gap:1rem; margin-bottom:1rem;">
              <label style="font-size:0.85rem; font-weight:600; color:#153b43;">Year
                <select name="year" style="width:100%; padding:0.6rem; border:1px solid #ccd7d6; border-radius:0.375rem; margin-top:0.25rem; font-size:0.95rem;">
                  <option value="">Select year</option>
                </select>
              </label>
              <label style="font-size:0.85rem; font-weight:600; color:#153b43;">Make
                <input list="detail_page-makes" name="make" placeholder="e.g. Ford, Toyota" style="width:100%; padding:0.6rem; border:1px solid #ccd7d6; border-radius:0.375rem; margin-top:0.25rem; font-size:0.95rem;"/>
                <datalist id="detail_page-makes"></datalist>
              </label>
            </div>

            <div style="display:grid; grid-template-columns: 1fr 1fr; gap:1rem; margin-bottom:1rem;">
              <label style="font-size:0.85rem; font-weight:600; color:#153b43;">Model
                <input name="model" placeholder="e.g. F-150, Camry" style="width:100%; padding:0.6rem; border:1px solid #ccd7d6; border-radius:0.375rem; margin-top:0.25rem; font-size:0.95rem;"/>
              </label>
              <label style="font-size:0.85rem; font-weight:600; color:#153b43;">ZIP Code
                <input name="zip" placeholder="Delivery ZIP" inputMode="numeric" style="width:100%; padding:0.6rem; border:1px solid #ccd7d6; border-radius:0.375rem; margin-top:0.25rem; font-size:0.95rem;"/>
              </label>
            </div>

            <div style="margin-bottom:1rem;">
              <label style="font-size:0.85rem; font-weight:600; color:#153b43;">Your Name
                <input name="name" placeholder="First and last name" style="width:100%; padding:0.6rem; border:1px solid #ccd7d6; border-radius:0.375rem; margin-top:0.25rem; font-size:0.95rem;"/>
              </label>
            </div>

            <div style="display:grid; grid-template-columns: 1fr 1fr; gap:1rem; margin-bottom:1rem;">
              <label style="font-size:0.85rem; font-weight:600; color:#153b43;">Phone Number
                <input type="tel" name="phone" placeholder="(555) 000-0000" style="width:100%; padding:0.6rem; border:1px solid #ccd7d6; border-radius:0.375rem; margin-top:0.25rem; font-size:0.95rem;"/>
              </label>
              <label style="font-size:0.85rem; font-weight:600; color:#153b43;">Email
                <input type="email" name="email" placeholder="name@email.com" style="width:100%; padding:0.6rem; border:1px solid #ccd7d6; border-radius:0.375rem; margin-top:0.25rem; font-size:0.95rem;"/>
              </label>
            </div>

            <div style="margin-bottom:1.25rem;">
              <label style="font-size:0.85rem; font-weight:600; color:#153b43;">Optional Notes
                <textarea name="notes" rows="2" placeholder="Engine size, VIN, trim, or part number" style="width:100%; padding:0.6rem; border:1px solid #ccd7d6; border-radius:0.375rem; margin-top:0.25rem; font-size:0.9rem;"></textarea>
              </label>
            </div>

            <label class="fmp-consent" style="margin-bottom:1.25rem; font-size:0.8rem; color:#52696f;">
              <input type="checkbox" name="consent" checked=""/>
              <span>I agree that Doorstep Auto Parts may call or email me about this part request.</span>
            </label>

            <button type="submit" class="button button-blue" style="width:100%; justify-content:center; padding:0.85rem; font-size:1.05rem;">
              Request ${title} Quote ↗
            </button>
          </form>
        </div>
      </div>
    </section>

    <!-- Part Specific FAQ Section -->
    <section class="section-pad" style="background:#eaf0ee;">
      <div class="shell" style="max-width:860px;">
        <div class="section-intro" style="margin-bottom:2rem; text-align:center;">
          <div>
            <p class="section-index">FAQ &amp; ADVICE / 003</p>
            <h2>Frequently Asked Questions About ${title}</h2>
          </div>
        </div>
        ${faqItems}
      </div>
    </section>
  </main>
  ${adjustedFooter}
</body>
</html>`;
}

// 1. Engine Detail Page (parts/engine.html)
console.log('Generating parts/engine.html...');
const engineHtml = createPartDetailPage({
  title: "Complete Engine & Engine Assembly",
  subtitle: "Sourced OEM Long Blocks, Short Blocks, and Complete Turnkey Assemblies",
  system: "Engine & Drivetrain",
  sysCode: "01",
  partSlug: "engine",
  desc: "Locate tested, low-mileage replacement engines for cars, trucks, and SUVs. Sourced from certified automotive dismantlers across the United States with verified compression and donor documentation.",
  specs: {
    "Configuration": "Long block (heads + block), complete turnkey assembly, or bare block",
    "Inspection Evidence": "Compression check, cylinder leak-down test, oil pan sludge inspection",
    "Mileage Documentation": "Verified via donor vehicle title, odometer cluster, or auction records",
    "Included Accessories": "Option-dependent: intake manifold, exhaust manifolds, injectors, alternator, sensors",
    "Freight Shipping": "LTL Palletized freight with liftgate service to residence or commercial repair shop",
    "Standard Warranty": "90-Day Standard Replacement to 1-Year Extended Warranty"
  },
  checklist: [
    "17-character Vehicle Identification Number (VIN) for exact engine code match",
    "Engine displacement, cylinder count, and fuel type (e.g. 5.3L V8 Gas, 2.0L Turbo)",
    "Drivetrain pairing (2WD, 4WD, AWD) as oil pans and motor mount bosses can vary",
    "Casting numbers stamped on cylinder head or engine block deck if available",
    "Commercial shop address with loading dock/forklift vs residential delivery address"
  ],
  faqs: [
    { q: "What is typically included with a used engine assembly?", a: "Standard used engines are sold as 'long blocks'—meaning the block, cylinder heads, crankshaft, camshafts, and internal components are included. Bolted accessories like the alternator, AC compressor, starter, and power steering pump may be left on for shipping convenience but are generally swapped from your original engine." },
    { q: "How is compression and engine health verified before shipping?", a: "Our partner dismantlers perform visual inspection for oil contamination, turn the crankshaft manually 360 degrees to verify free rotation, and perform hot or cold compression testing across all cylinders whenever donor battery power allows." },
    { q: "Do you ship engines to residential addresses?", a: "Yes! Engines ship palletized via freight carrier. If delivering to a residential address without a loading dock or forklift, we arrange a freight truck equipped with a hydraulic liftgate." }
  ],
  svgArt: `<div style="background:rgba(255,255,255,0.05); border:1px solid rgba(255,255,255,0.15); border-radius:1rem; padding:2rem; width:100%; max-width:440px; text-align:center;">
    <svg viewBox="0 0 100 100" width="160" height="160" fill="none" stroke="#91b8ff" stroke-width="1.8">
      <rect x="20" y="28" width="60" height="46" rx="4"></rect>
      <path d="M30 28V18h40v10M28 74v10m44-10v10M12 40h8m60 12h8M36 40h28M36 50h28M38 60h16"></path>
      <circle cx="50" cy="50" r="14" stroke="#f4f5f1" stroke-dasharray="3 3"></circle>
    </svg>
    <p style="font-family:var(--font-display); font-size:0.85rem; letter-spacing:0.05em; color:#91b8ff; text-transform:uppercase; margin-top:1rem;">
      SCHEMATIC REF: 01-ENG-LONGBLOCK
    </p>
  </div>`
});
fs.writeFileSync('d:/antigravity/v/parts/engine.html', engineHtml);

// 2. Transmission Detail Page (parts/transmission.html)
console.log('Generating parts/transmission.html...');
const transHtml = createPartDetailPage({
  title: "Transmission & Powertrain Assemblies",
  subtitle: "Automatic, Manual, and Continuously Variable (CVT) Transmissions",
  system: "Transmission & Powertrain",
  sysCode: "02",
  partSlug: "transmission",
  desc: "Find reliable used and remanufactured transmissions matched by VIN, transmission tag code, gear ratios, and torque converter configuration.",
  specs: {
    "Transmission Types": "Automatic (hydraulic & dual-clutch), Manual, and Continuously Variable (CVT)",
    "Case & Tag Verification": "Exact transmission barcode / stamped tag match to prevent ratio mismatches",
    "Torque Converter": "Included and inspected with automatic transmission units",
    "Fluid Inspection": "Fluid drained and pan checked for metal shavings or burnt clutches",
    "Shipping Method": "Palletized freight with secure banding and shrink wrap",
    "Warranty Options": "90-Day Standard Replacement to 1-Year Commercial Warranty"
  },
  checklist: [
    "Full 17-digit VIN to identify factory transmission option code (e.g. 10R80, 8HP70, 4L60E)",
    "Transmission identification sticker or metal tag stamped on the bellhousing or case",
    "Drive type: Front-Wheel Drive (FWD), Rear-Wheel Drive (RWD), 4WD, or All-Wheel Drive (AWD)",
    "Verification whether the transmission cooler must be flushed or replaced to satisfy warranty terms"
  ],
  faqs: [
    { q: "Is the torque converter included with an automatic transmission?", a: "Yes, our replacement automatic transmissions typically include the matching torque converter inspected for stator and hub condition." },
    { q: "Will the replacement transmission require computer programming?", a: "Many modern 6-speed, 8-speed, and 10-speed transmissions utilize an internal Transmission Control Module (TCM) or Mechatronic unit that requires a diagnostic scan tool relearn or VIN programming by your installer." },
    { q: "Why must I flush the transmission oil cooler during installation?", a: "When your original transmission failed, it likely released clutch material and metal debris into the radiator cooler and lines. Flushing or replacing the cooler prevents contamination from destroying your replacement unit." }
  ],
  svgArt: `<div style="background:rgba(255,255,255,0.05); border:1px solid rgba(255,255,255,0.15); border-radius:1rem; padding:2rem; width:100%; max-width:440px; text-align:center;">
    <svg viewBox="0 0 100 100" width="160" height="160" fill="none" stroke="#91b8ff" stroke-width="1.8">
      <path d="M18 36h52l12 14-12 14H18l-8-14zM32 36V22h24v14M32 64v10h24V64"></path>
      <circle cx="34" cy="50" r="7" stroke="#f4f5f1"></circle>
      <circle cx="60" cy="50" r="7" stroke="#f4f5f1"></circle>
    </svg>
    <p style="font-family:var(--font-display); font-size:0.85rem; letter-spacing:0.05em; color:#91b8ff; text-transform:uppercase; margin-top:1rem;">
      SCHEMATIC REF: 02-TRANS-GEARBOX
    </p>
  </div>`
});
fs.writeFileSync('d:/antigravity/v/parts/transmission.html', transHtml);

// 3. Transfer Case (parts/transfer-case.html)
console.log('Generating parts/transfer-case.html...');
const tcHtml = createPartDetailPage({
  title: "Transfer Case Assembly",
  subtitle: "4WD and All-Wheel-Drive Gearboxes for Trucks & SUVs",
  system: "Transmission & Powertrain",
  sysCode: "02",
  partSlug: "transfer-case",
  desc: "OEM replacement transfer cases checked for chain wear, internal clutch packs, electric shift encoder motors, and output shaft spline integrity.",
  specs: {
    "Drivetrain Scope": "Part-Time 4WD, Full-Time 4WD, and Electronic On-Demand AWD",
    "Inspection": "Output shaft play, internal chain stretch, fluid condition, and shift motor actuation",
    "Match Criteria": "RPO code (e.g. NP246, MP3023, NV271) and input gear spline tooth count",
    "Shipping": "Reinforced heavy-duty crate or pallet freight across the USA",
    "Warranty": "90-Day Standard Replacement"
  },
  checklist: [
    "Transfer case model number (stamped on the round metal identification tag)",
    "Input spline count (often differs between V6 and V8 transmission pairings)",
    "Shift type: manual floor lever vs dashboard electronic push-button switch",
    "Rear driveshaft yoke style: slip yoke vs fixed flange"
  ],
  faqs: [
    { q: "Is the electric shift motor included with the transfer case?", a: "Transfer cases typically include the encoder shift motor when available on the donor vehicle, though we always recommend verifying your plug pin configuration." },
    { q: "How do I check if my transfer case has the common pump rub failure?", a: "Our dismantlers inspect the rear magnesium case half specifically to ensure no oil pump anti-rotation tab wear has breached the casing." }
  ],
  svgArt: `<div style="background:rgba(255,255,255,0.05); border:1px solid rgba(255,255,255,0.15); border-radius:1rem; padding:2rem; width:100%; max-width:440px; text-align:center;">
    <svg viewBox="0 0 100 100" width="160" height="160" fill="none" stroke="#91b8ff" stroke-width="1.8">
      <circle cx="38" cy="50" r="22" stroke="#f4f5f1"></circle>
      <circle cx="68" cy="40" r="14" stroke="#91b8ff"></circle>
      <path d="M38 28h30M38 72l30-18"></path>
    </svg>
    <p style="font-family:var(--font-display); font-size:0.85rem; letter-spacing:0.05em; color:#91b8ff; text-transform:uppercase; margin-top:1rem;">
      SCHEMATIC REF: 02-TCASE-4X4
    </p>
  </div>`
});
fs.writeFileSync('d:/antigravity/v/parts/transfer-case.html', tcHtml);

// 4. Differential (parts/differential.html)
console.log('Generating parts/differential.html...');
const diffHtml = createPartDetailPage({
  title: "Front & Rear Differential Assembly",
  subtitle: "Carrier Assemblies, Ring & Pinion, and Axle Housings",
  system: "Transmission & Powertrain",
  sysCode: "02",
  partSlug: "differential",
  desc: "Sourced differential carriers and axle assemblies matched by gear ratio (e.g. 3.42, 3.73, 4.10), limited-slip / locker options, and brake configuration.",
  specs: {
    "Axle Locations": "Independent Front Differential (IFS), Independent Rear Differential (IRS), Solid Live Axle",
    "Inspection": "Ring & pinion gear mesh, tooth wear, pinion bearing preload, backlash measurement",
    "Ratio Matching": "Critical: front and rear gear ratios must match exactly on 4WD vehicles",
    "Differential Type": "Open differential, Limited Slip (LSD), Torsen, or Electronic Locking"
  },
  checklist: [
    "Differential axle ratio code from glovebox RPO sticker or axle tube stamp",
    "Tire size if altered from factory specifications",
    "Brake backing plate setup: drum vs disc brake mounting brackets",
    "ABS wheel speed sensor location (differential tone ring vs wheel hub sensor)"
  ],
  faqs: [
    { q: "Why is the gear ratio match so critical?", a: "On 4WD and AWD vehicles, running differing front and rear differential ratios will bind the drivetrain and instantly destroy the transfer case." },
    { q: "Is the differential filled with gear oil for delivery?", a: "No. All recycled automotive fluids are drained prior to shipping per DOT freight regulations. Fresh gear oil of the manufacturer-specified viscosity must be installed before driving." }
  ],
  svgArt: `<div style="background:rgba(255,255,255,0.05); border:1px solid rgba(255,255,255,0.15); border-radius:1rem; padding:2rem; width:100%; max-width:440px; text-align:center;">
    <svg viewBox="0 0 100 100" width="160" height="160" fill="none" stroke="#91b8ff" stroke-width="1.8">
      <circle cx="50" cy="50" r="26" stroke="#f4f5f1"></circle>
      <circle cx="50" cy="50" r="10" stroke="#91b8ff"></circle>
      <path d="M10 50h14M76 50h14M50 10v14M50 76v14"></path>
    </svg>
    <p style="font-family:var(--font-display); font-size:0.85rem; letter-spacing:0.05em; color:#91b8ff; text-transform:uppercase; margin-top:1rem;">
      SCHEMATIC REF: 02-DIFF-CARRIER
    </p>
  </div>`
});
fs.writeFileSync('d:/antigravity/v/parts/differential.html', diffHtml);

// 5. Front Bumper (parts/front-bumper.html)
console.log('Generating parts/front-bumper.html...');
const bumperHtml = createPartDetailPage({
  title: "Front Bumper & Bumper Cover Assembly",
  subtitle: "OEM Face Bars, Fascias, Reinforcements, and Brackets",
  system: "Body & Exterior",
  sysCode: "03",
  partSlug: "front-bumper",
  desc: "Find genuine OEM front bumper covers and assemblies. Matched to trim package, park assist sensors, adaptive cruise radar cutouts, and fog lamp styling.",
  specs: {
    "Material": "OEM Polypropylene (PP/TPO) flexible fascia or stamped chrome steel face bar",
    "Sensor Options": "Provisions for Ultrasonic Park Assist (PDC), Radar cruise, and Forward camera",
    "Fitment Verification": "Tab inspection ensuring zero broken retaining clips or distortion",
    "Paint Consideration": "Sourced used; paint code match is referenced but refinishing is standard"
  },
  checklist: [
    "Trim level (e.g. Base, Sport, Limited, Off-Road package)",
    "Count of parking sensor holes in the bumper face (e.g. 4-sensor vs 6-sensor)",
    "Presence of fog lights, daytime running light inserts, or lower skid plates",
    "Front collision warning or adaptive cruise radar grille opening"
  ],
  faqs: [
    { q: "Will the color match my car's paint code exactly?", a: "While we can search for your specific factory color code, paint naturally fades and shifts over time due to UV exposure. Most body shops recommend blending and repainting used bumper covers to achieve an undetectable color match." },
    { q: "Are mounting tabs and clip brackets intact?", a: "Yes. Our team inspects all critical headlamp and fender mounting tabs to guarantee straightforward installation without sagging." }
  ],
  svgArt: `<div style="background:rgba(255,255,255,0.05); border:1px solid rgba(255,255,255,0.15); border-radius:1rem; padding:2rem; width:100%; max-width:440px; text-align:center;">
    <svg viewBox="0 0 100 100" width="160" height="160" fill="none" stroke="#91b8ff" stroke-width="1.8">
      <path d="M12 45c10-8 30-10 38-10s28 2 38 10v18H12V45z" stroke="#f4f5f1"></path>
      <rect x="22" y="52" width="16" height="8" rx="2"></rect>
      <rect x="62" y="52" width="16" height="8" rx="2"></rect>
    </svg>
    <p style="font-family:var(--font-display); font-size:0.85rem; letter-spacing:0.05em; color:#91b8ff; text-transform:uppercase; margin-top:1rem;">
      SCHEMATIC REF: 03-BODY-BUMPER
    </p>
  </div>`
});
fs.writeFileSync('d:/antigravity/v/parts/front-bumper.html', bumperHtml);

// 6. Headlight (parts/headlight.html)
console.log('Generating parts/headlight.html...');
const hlHtml = createPartDetailPage({
  title: "Headlight & Headlamp Assembly",
  subtitle: "OEM Halogen, Xenon HID, Projector, and Adaptive LED Units",
  system: "Electrical & Lighting",
  sysCode: "05",
  partSlug: "headlight",
  desc: "Replace foggy or collision-damaged headlights with genuine OEM assemblies. Verified for clear lens clarity, unbroken mounting tabs, and intact wiring harnesses.",
  specs: {
    "Lighting Technologies": "Halogen reflector, Bi-Xenon HID projector, and Full Adaptive Matrix LED",
    "Position": "Left (Driver Side) or Right (Passenger Side) from seated position",
    "Internal Ballasts": "OEM ballast or LED driver module included where specified on donor item",
    "Lens Condition": "Crystal clear polycarbonate lens inspected with zero stress cracks or moisture"
  },
  checklist: [
    "Side needed: Driver Side (Left) or Passenger Side (Right)",
    "Factory bulb type: Standard Halogen vs Factory HID Xenon vs Matrix LED",
    "Housing bezel finish: Chrome / Bright finish vs Blacked-Out / Sport trim",
    "Wiring harness pin count on the main plug connector"
  ],
  faqs: [
    { q: "Why should I buy a used OEM headlight instead of a cheap aftermarket one?", a: "Used OEM headlights retain factory optical beam patterns, UV-resistant lens coatings, and sealed housings that don't develop internal fogging or yellowing like cheap overseas reproductions." },
    { q: "Are the mounting ears and tabs intact?", a: "Yes. Headlights with broken mounting tabs are rejected by our quality inspectors." }
  ],
  svgArt: `<div style="background:rgba(255,255,255,0.05); border:1px solid rgba(255,255,255,0.15); border-radius:1rem; padding:2rem; width:100%; max-width:440px; text-align:center;">
    <svg viewBox="0 0 100 100" width="160" height="160" fill="none" stroke="#91b8ff" stroke-width="1.8">
      <path d="M25 32c25-10 45-2 52 16l-8 28c-22 4-46-8-44-44z" stroke="#f4f5f1"></path>
      <circle cx="56" cy="50" r="10" stroke="#91b8ff"></circle>
    </svg>
    <p style="font-family:var(--font-display); font-size:0.85rem; letter-spacing:0.05em; color:#91b8ff; text-transform:uppercase; margin-top:1rem;">
      SCHEMATIC REF: 05-LIGHT-HEADLAMP
    </p>
  </div>`
});
fs.writeFileSync('d:/antigravity/v/parts/headlight.html', hlHtml);

// 7. Alternator (parts/alternator.html)
console.log('Generating parts/alternator.html...');
const altHtml = createPartDetailPage({
  title: "Alternator & Charging Generator",
  subtitle: "Bench-Tested High-Output Alternators for All Makes",
  system: "Electrical & Lighting",
  sysCode: "04",
  partSlug: "alternator",
  desc: "OEM automotive alternators bench-tested for amperage output, voltage regulator stability, and internal diode ripple.",
  specs: {
    "Output Rating": "Matched to factory specification (e.g. 110A, 150A, 220A heavy-duty)",
    "Pulley Type": "Standard multi-rib serpentine pulley or Decoupler / One-Way Clutch pulley",
    "Connector": "Factory plug pin count and BAT+ terminal stud integrity verified",
    "Testing": "Full bench load test checking for stator heat and diode breakdown"
  },
  checklist: [
    "Amperage rating stamped on alternator label",
    "Number of wiring connector pins (e.g. 2-pin, 3-pin, 4-pin plug)",
    "Clutch decoupler pulley vs standard solid pulley",
    "Engine size and air conditioning / heated seat options affecting amperage draw"
  ],
  faqs: [
    { q: "How do I know the alternator isn't dead on arrival?", a: "Every unit is bench tested under simulated electrical load to verify that voltage regulates steadily between 13.8V and 14.6V." }
  ],
  svgArt: `<div style="background:rgba(255,255,255,0.05); border:1px solid rgba(255,255,255,0.15); border-radius:1rem; padding:2rem; width:100%; max-width:440px; text-align:center;">
    <svg viewBox="0 0 100 100" width="160" height="160" fill="none" stroke="#91b8ff" stroke-width="1.8">
      <circle cx="50" cy="50" r="26" stroke="#f4f5f1"></circle>
      <circle cx="50" cy="50" r="10" stroke="#91b8ff"></circle>
      <path d="M30 20h40M30 80h40"></path>
    </svg>
    <p style="font-family:var(--font-display); font-size:0.85rem; letter-spacing:0.05em; color:#91b8ff; text-transform:uppercase; margin-top:1rem;">
      SCHEMATIC REF: 04-ELEC-CHARGING
    </p>
  </div>`
});
fs.writeFileSync('d:/antigravity/v/parts/alternator.html', altHtml);

// 8. AC Compressor (parts/ac-compressor.html)
console.log('Generating parts/ac-compressor.html...');
const acHtml = createPartDetailPage({
  title: "AC Compressor & Climate Control Pump",
  subtitle: "Tested Air Conditioning Compressors with Magnetic Clutch",
  system: "Cooling & HVAC",
  sysCode: "06",
  partSlug: "ac-compressor",
  desc: "OEM air conditioning compressors tested for clutch coil engagement, smooth shaft rotation, and suction / discharge valve compression.",
  specs: {
    "Refrigerant Compatibility": "R-134a or R-1234yf specific factory oil and seal types",
    "Clutch Assembly": "12-Volt electromagnetic clutch and pulley bearing tested",
    "Inspection": "Shaft rotated manually to confirm no internal lockup or scoring",
    "Warranty Requirement": "System must be flushed and accumulator/receiver-drier replaced"
  },
  checklist: [
    "Compressor manufacturer & model number (e.g. Denso 10S20F, Sanden, Delphi)",
    "Refrigerant type (R134a vs R1234yf)",
    "Mounting bolt pattern and manifold hose connection port orientation"
  ],
  faqs: [
    { q: "Why must I replace the drier and expansion valve when replacing a compressor?", a: "When an AC compressor fails, it sheds microscopic debris. Installing a replacement compressor without a clean system will immediately ruin the new unit and void warranty coverage." }
  ],
  svgArt: `<div style="background:rgba(255,255,255,0.05); border:1px solid rgba(255,255,255,0.15); border-radius:1rem; padding:2rem; width:100%; max-width:440px; text-align:center;">
    <svg viewBox="0 0 100 100" width="160" height="160" fill="none" stroke="#91b8ff" stroke-width="1.8">
      <rect x="25" y="30" width="50" height="40" rx="8" stroke="#f4f5f1"></rect>
      <circle cx="78" cy="50" r="14" stroke="#91b8ff"></circle>
      <line x1="40" y1="30" x2="40" y2="20"></line>
      <line x1="60" y1="30" x2="60" y2="20"></line>
    </svg>
    <p style="font-family:var(--font-display); font-size:0.85rem; letter-spacing:0.05em; color:#91b8ff; text-transform:uppercase; margin-top:1rem;">
      SCHEMATIC REF: 06-HVAC-COMPRESSOR
    </p>
  </div>`
});
fs.writeFileSync('d:/antigravity/v/parts/ac-compressor.html', acHtml);

// 9. Steering Rack (parts/steering-rack.html)
console.log('Generating parts/steering-rack.html...');
const srHtml = createPartDetailPage({
  title: "Steering Rack & Pinion Assembly",
  subtitle: "Hydraulic and Electric Power Steering (EPS) Gearboxes",
  system: "Steering & Suspension",
  sysCode: "07",
  partSlug: "steering-rack",
  desc: "Find genuine OEM steering racks with verified rack teeth, input shaft splines, intact dust boots, and electric assist motor diagnostics.",
  specs: {
    "Steering Assist": "Hydraulic Power Steering (HPS) or Electric Power Steering (EPS / EPAS)",
    "Sensor Integration": "Steering angle sensor and torque sensor diagnostic scan verified",
    "Mechanical Check": "End-to-end travel tested for binding, notched teeth, or excessive play"
  },
  checklist: [
    "Hydraulic vs Electric assist on rack",
    "Variable ratio steering option codes",
    "Inner tie rod end condition and thread pitch"
  ],
  faqs: [
    { q: "Does an electric power steering rack require computer calibration?", a: "Yes, once installed, an EPS rack requires a steering angle sensor zero-point calibration using an OBD-II diagnostic scan tool." }
  ],
  svgArt: `<div style="background:rgba(255,255,255,0.05); border:1px solid rgba(255,255,255,0.15); border-radius:1rem; padding:2rem; width:100%; max-width:440px; text-align:center;">
    <svg viewBox="0 0 100 100" width="160" height="160" fill="none" stroke="#91b8ff" stroke-width="1.8">
      <line x1="12" y1="50" x2="88" y2="50" stroke="#f4f5f1" stroke-width="4"></line>
      <circle cx="50" cy="50" r="16" stroke="#91b8ff"></circle>
      <line x1="50" y1="34" x2="50" y2="16"></line>
    </svg>
    <p style="font-family:var(--font-display); font-size:0.85rem; letter-spacing:0.05em; color:#91b8ff; text-transform:uppercase; margin-top:1rem;">
      SCHEMATIC REF: 07-STEER-GEARBOX
    </p>
  </div>`
});
fs.writeFileSync('d:/antigravity/v/parts/steering-rack.html', srHtml);

// 10. Brake Caliper (parts/brake-caliper.html)
console.log('Generating parts/brake-caliper.html...');
const bcHtml = createPartDetailPage({
  title: "Brake Caliper & Hydraulic Assembly",
  subtitle: "Front & Rear Calipers with Slide Pins & Mounting Brackets",
  system: "Braking Systems",
  sysCode: "08",
  partSlug: "brake-caliper",
  desc: "OEM hydraulic brake calipers inspected for smooth piston movement, undamaged dust seals, bleeder screw threads, and bracket alignment.",
  specs: {
    "Piston Style": "Single, Dual, 4-Piston, or 6-Piston Brembo / Performance calipers",
    "Parking Brake": "Mechanical cable lever or Electronic Parking Brake (EPB) integrated actuator motor",
    "Bracket": "Includes matching caliper mounting torque bracket and guide pins"
  },
  checklist: [
    "Front vs Rear and Driver (Left) vs Passenger (Right) side",
    "Rotor diameter / Heavy-Duty brake package option",
    "Electronic parking brake motor plug orientation"
  ],
  faqs: [
    { q: "Is the caliper bracket included?", a: "Yes, our calipers are supplied with the mounting bracket and inspected slide pins." }
  ],
  svgArt: `<div style="background:rgba(255,255,255,0.05); border:1px solid rgba(255,255,255,0.15); border-radius:1rem; padding:2rem; width:100%; max-width:440px; text-align:center;">
    <svg viewBox="0 0 100 100" width="160" height="160" fill="none" stroke="#91b8ff" stroke-width="1.8">
      <path d="M25 25h45q15 0 15 15v20q0 15-15 15H25z" stroke="#f4f5f1"></path>
      <circle cx="50" cy="50" r="14" stroke="#91b8ff"></circle>
    </svg>
    <p style="font-family:var(--font-display); font-size:0.85rem; letter-spacing:0.05em; color:#91b8ff; text-transform:uppercase; margin-top:1rem;">
      SCHEMATIC REF: 08-BRAKE-CALIPER
    </p>
  </div>`
});
fs.writeFileSync('d:/antigravity/v/parts/brake-caliper.html', bcHtml);

// 11. Generic Dynamic Viewer for all remaining 92 parts (parts/part-detail.html)
console.log('Generating parts/part-detail.html...');
const dynamicPartHtml = createPartDetailPage({
  title: "Automotive Replacement Part",
  subtitle: "OEM Tested Auto Part with Guaranteed Fitment",
  system: "Auto Parts Directory",
  sysCode: "00",
  partSlug: "part-detail",
  desc: "Sourced replacement auto parts inspected for condition, fitment codes, and verified against donor vehicle records across the USA.",
  specs: {
    "Sourcing Range": "Verified automotive recyclers and certified salvage networks across the United States",
    "Fitment Protocol": "Triple-checked against year, make, model, trim, and 17-digit VIN",
    "Shipping Service": "Direct carrier delivery to residential and repair shop commercial addresses",
    "Standard Warranty": "90-Day Standard Replacement Guarantee with optional extended coverage"
  },
  checklist: [
    "Vehicle year, make, model, and trim package",
    "Full 17-character VIN number",
    "Part number stamped or labeled on original component",
    "Delivery ZIP code for freight and ground shipping estimates"
  ],
  faqs: [
    { q: "How do I confirm this part fits my vehicle?", a: "Share your 17-character VIN when submitting your request. Our parts specialist decodes the exact build sheet and confirms fitment before you buy." }
  ],
  svgArt: `<div style="background:rgba(255,255,255,0.05); border:1px solid rgba(255,255,255,0.15); border-radius:1rem; padding:2rem; width:100%; max-width:440px; text-align:center;">
    <svg viewBox="0 0 100 100" width="160" height="160" fill="none" stroke="#91b8ff" stroke-width="1.8">
      <circle cx="50" cy="50" r="32" stroke="#f4f5f1"></circle>
      <circle cx="50" cy="50" r="16" stroke="#91b8ff"></circle>
      <path d="M50 18v12M50 70v12M18 50h12M70 50h12"></path>
    </svg>
    <p style="font-family:var(--font-display); font-size:0.85rem; letter-spacing:0.05em; color:#91b8ff; text-transform:uppercase; margin-top:1rem;" id="dynamic-schematic-ref">
      SCHEMATIC REF: 00-OEM-COMPONENT
    </p>
  </div>`
});
// Add small script to dynamic page to update title from URL param if present
const dynamicScript = `
  <script>
    document.addEventListener("DOMContentLoaded", () => {
      const p = new URLSearchParams(window.location.search).get("part");
      if (p) {
        document.title = p + " Online Across the USA | Doorstep Auto Parts";
        const h1 = document.querySelector(".part-detail-hero h1");
        if (h1) h1.innerHTML = p.toUpperCase() + "<br/><em style='color:#91b8ff; font-style:normal;'>OEM &amp; REPLACEMENT.</em>";
        document.querySelectorAll("input[name='part']").forEach(i => i.value = p);
        const ref = document.getElementById("dynamic-schematic-ref");
        if (ref) ref.textContent = "SCHEMATIC REF: OEM-" + p.toUpperCase().replace(/\\s+/g, '-');
      }
    });
  </script>
</body>`;
const finalDynamicHtml = dynamicPartHtml.replace('</body>', dynamicScript);
fs.writeFileSync('d:/antigravity/v/parts/part-detail.html', finalDynamicHtml);

console.log('All parts pages created successfully!');
