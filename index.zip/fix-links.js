const fs = require('fs');
const path = require('path');

function fixFile(filePath) {
  let content = fs.readFileSync(filePath, 'utf-8');
  const isSubdir = filePath.includes('\\blog\\') || filePath.includes('/blog/') || filePath.includes('\\parts\\') || filePath.includes('/parts/');
  const prefix = isSubdir ? '../' : '';

  // Replace remote links
  content = content.replace(/href="https:\/\/doorstepautoparts\.com\/used-car-parts"/g, `href="${prefix}used-car-parts.html"`);
  content = content.replace(/href="https:\/\/doorstepautoparts\.com\/used-car-parts#([^"]+)"/g, `href="${prefix}used-car-parts.html#$1"`);
  content = content.replace(/href="https:\/\/doorstepautoparts\.com\/find-a-part\/?"/g, `href="${prefix}find-a-part.html"`);
  content = content.replace(/href="https:\/\/doorstepautoparts\.com\/faq"/g, `href="${prefix}faq.html"`);
  content = content.replace(/href="https:\/\/doorstepautoparts\.com\/blog"/g, `href="${prefix}blog.html"`);
  content = content.replace(/href="https:\/\/doorstepautoparts\.com\/blog\/([a-z0-9-]+)"/g, `href="${prefix}blog/$1.html"`);
  content = content.replace(/href="https:\/\/doorstepautoparts\.com\/#([^"]+)"/g, `href="${prefix}index.html#$1"`);
  content = content.replace(/href="https:\/\/doorstepautoparts\.com\/?"/g, `href="${prefix}index.html"`);

  // Fix any remaining /assets or /brand root links in subdirs
  if (isSubdir) {
    content = content.replace(/href="\/assets\//g, 'href="../assets/');
    content = content.replace(/src="\/assets\//g, 'src="../assets/');
    content = content.replace(/href="\/brand\//g, 'href="../brand/');
    content = content.replace(/src="\/brand\//g, 'src="../brand/');
    content = content.replace(/href="\/visuals\//g, 'href="../visuals/');
    content = content.replace(/src="\/visuals\//g, 'src="../visuals/');
  } else {
    content = content.replace(/href="\/assets\//g, 'href="assets/');
    content = content.replace(/src="\/assets\//g, 'src="assets/');
    content = content.replace(/href="\/brand\//g, 'href="brand/');
    content = content.replace(/src="\/brand\//g, 'src="brand/');
    content = content.replace(/href="\/visuals\//g, 'href="visuals/');
    content = content.replace(/src="\/visuals\//g, 'src="visuals/');
  }

  fs.writeFileSync(filePath, content, 'utf-8');
}

function walk(dir) {
  for (const item of fs.readdirSync(dir)) {
    const full = path.join(dir, item);
    if (fs.statSync(full).isDirectory()) {
      if (item !== 'node_modules' && item !== '.git') walk(full);
    } else if (item.endsWith('.html')) {
      fixFile(full);
    }
  }
}

walk('d:/antigravity/v');
console.log('All links normalized!');
