const http = require('http');

const endpoints = [
  '/',
  '/index.html',
  '/used-car-parts',
  '/used-car-parts.html',
  '/all-parts',
  '/all-parts.html',
  '/find-a-part',
  '/find-a-part.html',
  '/faq',
  '/faq.html',
  '/blog',
  '/blog.html',
  '/blog/how-to-buy-a-used-engine',
  '/blog/find-car-parts-by-vin',
  '/blog/used-vs-rebuilt-vs-remanufactured-transmissions',
  '/blog/used-car-parts-fitment-mistakes',
  '/blog/used-auto-parts-total-cost-guide',
  '/parts/engine',
  '/parts/transmission',
  '/parts/transfer-case',
  '/parts/differential',
  '/parts/front-bumper',
  '/parts/headlight',
  '/parts/alternator',
  '/parts/ac-compressor',
  '/parts/steering-rack',
  '/parts/brake-caliper',
  '/parts/part-detail',
  '/brand/logo-selected-dark.svg',
  '/brand/bbb-logo-official.svg',
  '/visuals/brake-assembly.svg',
  '/assets/styles.css',
  '/assets/custom.css',
  '/assets/main.js'
];

async function checkUrl(urlPath) {
  return new Promise((resolve) => {
    http.get(`http://localhost:3000${urlPath}`, (res) => {
      let data = '';
      res.on('data', chunk => data += chunk);
      res.on('end', () => {
        resolve({
          path: urlPath,
          status: res.statusCode,
          contentType: res.headers['content-type'],
          length: data.length
        });
      });
    }).on('error', (err) => {
      resolve({ path: urlPath, status: 'ERROR', error: err.message });
    });
  });
}

async function run() {
  console.log(`Checking ${endpoints.length} endpoints on http://localhost:3000...\n`);
  let passed = 0;
  for (const ep of endpoints) {
    const res = await checkUrl(ep);
    const ok = res.status === 200 && res.length > 0;
    if (ok) {
      passed++;
      console.log(`[PASS] 200 OK (${res.length} B) ${ep}`);
    } else {
      console.log(`[FAIL] ${res.status} ${ep} - ${res.error || 'Empty'}`);
    }
  }
  console.log(`\nResults: ${passed} / ${endpoints.length} passed.`);
}

run();
