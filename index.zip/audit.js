const fs = require('fs');
const path = require('path');

function checkFile(filePath) {
  const content = fs.readFileSync(filePath, 'utf-8');
  const issues = [];
  
  // Check for unhandled doorstepautoparts.com links
  const matches = content.match(/href="https?:\/\/doorstepautoparts\.com[^"']*/g);
  if (matches) {
    issues.push('Remote doorstep URLs: ' + matches.slice(0, 5).join(', '));
  }
  
  // Check for absolute root /assets or /brand links that should be relative
  const absAssets = content.match(/src="\/(brand|assets|visuals)\/[^"']*/g);
  if (absAssets) {
    issues.push('Absolute root asset URLs: ' + absAssets.slice(0, 3).join(', '));
  }

  return issues;
}

function walk(dir) {
  let files = [];
  for (const item of fs.readdirSync(dir)) {
    const full = path.join(dir, item);
    if (fs.statSync(full).isDirectory()) {
      if (item !== 'node_modules' && item !== '.git') files = files.concat(walk(full));
    } else if (item.endsWith('.html')) {
      files.push(full);
    }
  }
  return files;
}

const htmlFiles = walk('d:/antigravity/v');
console.log('Checking', htmlFiles.length, 'HTML files...');
for (const f of htmlFiles) {
  const issues = checkFile(f);
  if (issues.length > 0) {
    console.log('File:', f);
    issues.forEach(i => console.log('  -', i));
  }
}
console.log('Link audit completed!');
