# Doorstep Auto Parts - Full Website Replica & All Parts Directory

A complete, high-fidelity replica of **[Doorstep Auto Parts](https://doorstepautoparts.com/)** featuring all original branding, styling, animations, interactive forms, comprehensive customer FAQs, automotive journal guides, and an expanded **All Parts Directory** covering all 102 automotive replacement parts across 9 primary vehicle systems.

---

## 🚀 Quick Start

Run the website locally using the included lightweight zero-dependency server:

```bash
npm run dev
# or
node server.js
```

Then open your browser at **[http://localhost:3000](http://localhost:3000)**.

Alternatively, you can open any of the `.html` files directly in any web browser without needing a server, as all assets use relative pathing!

---

## 📑 Pages & Routes Included

### 1. Primary Pages
* **Homepage** (`/` or `index.html`)
  * Full dark-mode petrol aesthetic with rotating orbit animations around the precision metallic brake assembly
  * Why Shop Doorstep benefits rail (First-Order Offer, Super Fast & Free Delivery, Quality Used Auto Parts)
  * Interactive 3-step part request wizard with year selector (1980–2026), 90+ vehicle makes datalist, and 102 parts datalist
  * Popular parts interactive categories (Engine, Transmission, Bumper, Electrical, Cooling, Steering, Brakes) with click-to-prefill action
  * The Process (`003`), Precision Blueprint (`004`), Why Doorstep (`005`), and Assurance section
  * Buyer education highlights, 7 top FAQs with interactive toggles, and full footer with Better Business Bureau (BBB) branding

* **All Parts Directory** (`/all-parts` or `all-parts.html`)
  * Complete catalog featuring all **102 automotive replacement parts**
  * Real-time client-side search bar and system filters
  * Technical installation difficulty rating (`Easy`, `Moderate`, `Advanced`) and warranty tiers
  * Direct "View Specs" and "Request Quote" buttons for every part

* **Used Car Parts Directory** (`/used-car-parts` or `used-car-parts.html`)
  * Full replica of the official used parts directory
  * 9 system categories: Engine, Transmission, Body, Electrical, Lighting, Cooling, Steering, Brakes, and Interior
  * Quick-click vehicle make pills (Ford, Chevrolet, Toyota, Honda, Ram, GMC, Jeep, BMW, etc.)
  * Comparison guide: Used OEM vs. Rebuilt vs. New Aftermarket
  * 6-point pre-purchase checklist and 10 comprehensive FAQs

* **Find a Part Request** (`/find-a-part` or `find-a-part.html`)
  * Dedicated part request page matching Doorstep's specialized form
  * Auto-prefills from URL query parameters (e.g. `?part=Transmission&make=Ford&year=2021`)
  * Instant submission feedback with generated reference code (e.g. `DS-89421`) and confirmation modal

* **FAQs Knowledge Center** (`/faq` or `faq.html`)
  * Complete 20-question reference covering finding parts, fitment & VIN checks, mechanical assemblies, and shipping/warranty
  * Real-time dynamic search filter highlighting matches as you type
  * Topic navigation anchors: Finding, Fitment, Components, and Purchase

* **Doorstep Journal** (`/blog` or `blog.html`)
  * Field guides and buyer resources featuring Issue 02
  * Technical illustrations, reading times, and topic badges

---

### 2. Dedicated Part Detail Pages (`/parts/`)
High-precision technical specification pages featuring pre-order fitment checklists, schematic blueprints, and dedicated request forms:

* **Engine & Engine Components** (`/parts/engine.html`)
* **Transmission & Drivetrain** (`/parts/transmission.html`)
* **Transfer Case (4WD/AWD)** (`/parts/transfer-case.html`)
* **Front & Rear Differential** (`/parts/differential.html`)
* **Front Bumper & Fascia** (`/parts/front-bumper.html`)
* **Headlight & Lighting Assemblies** (`/parts/headlight.html`)
* **Alternator & Charging System** (`/parts/alternator.html`)
* **AC Compressor & HVAC** (`/parts/ac-compressor.html`)
* **Steering Rack & Pinion** (`/parts/steering-rack.html`)
* **Brake Caliper & Assembly** (`/parts/brake-caliper.html`)
* **Dynamic Part Viewer** (`/parts/part-detail.html?part=...`) — Supports all remaining 92 parts!

---

### 3. Automotive Journal In-Depth Guides (`/blog/`)
* **How to Buy a Used Engine** (`/blog/how-to-buy-a-used-engine.html`) — Complete 12-point inspection checklist
* **Find Car Parts Using Your VIN** (`/blog/find-car-parts-by-vin.html`) — 17-character VIN decoding & OEM verification
* **Used vs. Rebuilt vs. Remanufactured Transmissions** (`/blog/used-vs-rebuilt-vs-remanufactured-transmissions.html`)
* **Same Car, Wrong Part: Fitment Mistakes** (`/blog/used-car-parts-fitment-mistakes.html`) — 12 fitment checks beyond Year, Make & Model
* **The Real Cost of Used Auto Parts** (`/blog/used-auto-parts-total-cost-guide.html`) — ARA part grades, freight, core charges, and installed total

---

## 🎨 Design & Assets
* **Official Vector Logos & Visuals**:
  * `brand/logo-selected-dark.svg` — Official Doorstep Auto Parts piston vector mark with embedded typography
  * `brand/bbb-logo-official.svg` — Better Business Bureau verified badge
  * `brand/favicon-option-b.svg` — Piston brand favicon
  * `visuals/brake-assembly.svg` — Multi-layered metallic brake rotor & caliper illustration
* **Typography**: Google Fonts `"IBM Plex Sans"` (body) and `"Barlow Semi Condensed"` (display titles & technical labels)
* **Color Palette**:
  * Deep Dark Petrol: `#153b43`, `#0b2932`, `#0f1f23`
  * Electric Accent Blue: `#225bd6`, `#91b8ff`
  * Ceramic White: `#f4f5f1`
* **Styling**: Complete Tailwind CSS stylesheet (`assets/styles.css`) + custom component polish (`assets/custom.css`)

---

## 🛠️ Interactivity Features (`assets/main.js`)
* **Interactive 3-Step Form**: Live Year/Make/Model dropdowns, VIN character limiter, and phone formatting
* **Modal Quote Confirmation**: Animated popup displaying request reference number, vehicle configuration, and immediate callback details
* **Real-Time Live Search**: Filters FAQ accordions and parts catalog with instant count updating
* **Category Auto-Fill**: Clicking any category or popular part card automatically pre-selects the part and scrolls smoothly to the request form
* **Responsive Mobile Menu**: Smooth slide-down navigation menu with touch-friendly navigation anchors
